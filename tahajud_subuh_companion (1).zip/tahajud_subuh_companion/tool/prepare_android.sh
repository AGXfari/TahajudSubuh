#!/usr/bin/env bash
# Melengkapi kerangka Android yang sengaja tidak disimpan di repo (Gradle wrapper,
# settings, build.gradle.kts, ikon) memakai template Flutter yang terpasang,
# lalu menyesuaikannya dengan kode native aplikasi ini.
#
# Pakai:  bash tool/prepare_android.sh   (sekali, sebelum flutter build apk)
set -euo pipefail
cd "$(dirname "$0")/.."

# flutter create hanya membuat file yang belum ada; file milik kita tidak ditimpa.
flutter create --org id.tahajud --project-name tahajud_subuh_companion --platforms android .

GRADLE=android/app/build.gradle.kts
if [ ! -f "$GRADLE" ]; then
  echo "Tidak menemukan $GRADLE. Gunakan Flutter 3.44 atau lebih baru." >&2
  exit 1
fi
sed -i.bak -E 's/namespace = "[^"]*"/namespace = "id.tahajud.companion"/' "$GRADLE"
sed -i.bak -E 's/applicationId = "[^"]*"/applicationId = "id.tahajud.companion"/' "$GRADLE"
sed -i.bak -E 's/minSdk = .*/minSdk = 26/' "$GRADLE"
grep -q 'androidx.core:core-ktx' "$GRADLE" || printf '\ndependencies {\n    implementation("androidx.core:core-ktx:1.13.1")\n}\n' >> "$GRADLE"
rm -f "$GRADLE.bak"

# File template yang bentrok dengan kode kita.
rm -rf android/app/src/main/kotlin/id/tahajud/tahajud_subuh_companion  # MainActivity bawaan
rm -rf android/app/src/main/res/values-night                            # tema terang saat mode gelap
rm -f test/widget_test.dart                                             # tes contoh counter

echo "Kerangka Android siap. Lanjutkan: flutter pub get && flutter build apk --release"

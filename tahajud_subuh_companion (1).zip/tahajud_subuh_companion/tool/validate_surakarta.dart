// Validasi mesin waktu salat terhadap jadwal resmi Kemenag (Bimas Islam)
// Kota Surakarta, November 2026. Jalankan: dart run tool/validate_surakarta.dart
import '../lib/core/astronomy/prayer_time_calculator.dart';
import '../lib/core/astronomy/night_third_calculator.dart';

// tanggal: [subuh, dzuhur, ashar, maghrib, isya]
const kemenag = <int, List<String>>{
  1: ['03:51', '11:24', '14:38', '17:35', '18:46'],
  2: ['03:51', '11:24', '14:38', '17:35', '18:47'],
  3: ['03:50', '11:24', '14:39', '17:35', '18:47'],
  4: ['03:50', '11:24', '14:39', '17:35', '18:47'],
  5: ['03:50', '11:24', '14:40', '17:36', '18:48'],
  6: ['03:49', '11:24', '14:40', '17:36', '18:48'],
  7: ['03:49', '11:24', '14:41', '17:36', '18:48'],
  8: ['03:49', '11:24', '14:41', '17:36', '18:49'],
  9: ['03:49', '11:24', '14:42', '17:37', '18:49'],
  10: ['03:48', '11:24', '14:42', '17:37', '18:49'],
  11: ['03:48', '11:24', '14:43', '17:37', '18:50'],
  12: ['03:48', '11:24', '14:43', '17:37', '18:50'],
  13: ['03:48', '11:24', '14:44', '17:38', '18:51'],
  14: ['03:48', '11:25', '14:44', '17:38', '18:51'],
  15: ['03:47', '11:25', '14:45', '17:38', '18:51'],
  16: ['03:47', '11:25', '14:45', '17:39', '18:52'],
  17: ['03:47', '11:25', '14:46', '17:39', '18:52'],
  18: ['03:47', '11:25', '14:46', '17:39', '18:53'],
  19: ['03:47', '11:26', '14:47', '17:40', '18:53'],
  20: ['03:47', '11:26', '14:47', '17:40', '18:54'],
  21: ['03:47', '11:26', '14:48', '17:40', '18:54'],
  22: ['03:47', '11:26', '14:49', '17:41', '18:55'],
  23: ['03:47', '11:26', '14:49', '17:41', '18:55'],
  24: ['03:47', '11:27', '14:50', '17:42', '18:56'],
  25: ['03:47', '11:27', '14:50', '17:42', '18:56'],
  26: ['03:47', '11:27', '14:51', '17:42', '18:57'],
  27: ['03:47', '11:28', '14:51', '17:43', '18:58'],
  28: ['03:47', '11:28', '14:52', '17:43', '18:58'],
  29: ['03:47', '11:28', '14:52', '17:44', '18:59'],
  30: ['03:47', '11:29', '14:53', '17:44', '18:59'],
};

String hm(DateTime utc) {
  final l = utc.add(const Duration(hours: 7)); // WIB
  return '${l.hour.toString().padLeft(2, '0')}:${l.minute.toString().padLeft(2, '0')}';
}

int diffMin(String a, String b) {
  int m(String s) => int.parse(s.substring(0, 2)) * 60 + int.parse(s.substring(3));
  return m(a) - m(b);
}

void main(List<String> args) {
  final lat = args.isNotEmpty ? double.parse(args[0]) : -7.57;
  final lng = args.length > 1 ? double.parse(args[1]) : 110.82;
  final elev = args.length > 2 ? double.parse(args[2]) : 0.0;
  final verbose = args.contains('-v');
  final loc = GeoPoint(lat, lng, elevation: elev);
  const calc = PrayerTimeCalculator(method: CalculationMethod.kemenag);
  final names = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
  final exact = List.filled(5, 0), within1 = List.filled(5, 0);
  final maxAbs = List.filled(5, 0);
  for (final e in kemenag.entries) {
    final t = calc.compute(loc, 2026, 11, e.key);
    final ours = [t.fajr, t.dhuhr, t.asr, t.maghrib, t.isha].map(hm).toList();
    for (var i = 0; i < 5; i++) {
      final d = diffMin(ours[i], e.value[i]);
      if (d == 0) exact[i]++;
      if (d.abs() <= 1) within1[i]++;
      if (d.abs() > maxAbs[i]) maxAbs[i] = d.abs();
      if (verbose && d != 0) print('Nov ${e.key} ${names[i]}: kita ${ours[i]} vs Kemenag ${e.value[i]}');
    }
  }
  final n = kemenag.length;
  print('Lokasi $lat, $lng, elevasi $elev m — $n hari');
  for (var i = 0; i < 5; i++) {
    print('${names[i].padRight(8)} sama persis ${exact[i]}/$n, selisih ≤1 menit ${within1[i]}/$n, maks ${maxAbs[i]} menit');
  }

  // Contoh sepertiga malam: malam Kamis 29 Okt → Jumat 30 Okt 2026.
  final nights = NightThirdCalculator(calc, loc);
  final night = nights.forEvening(DateTime(2026, 10, 29));
  print('\nMalam 29→30 Okt 2026: Maghrib ${hm(night.maghrib)}, Subuh ${hm(night.fajr)}, '
      'durasi ${night.duration.inMinutes} menit');
  print('Sepertiga kedua mulai ${hm(night.secondThirdStart)}, '
      'sepertiga terakhir mulai ${hm(night.lastThirdStart)}, '
      'alarm (LastThirdRule) ${hm(const LastThirdRule().resolve(night))}');
  print('Alarm 10 menit sebelum Subuh: ${hm(const BeforeFajrRule(minutesBefore: 10).resolve(night))}');
}

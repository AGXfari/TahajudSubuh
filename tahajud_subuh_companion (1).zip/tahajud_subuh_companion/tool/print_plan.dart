// Mencetak rencana alarm 7 malam untuk Surakarta (zona perangkat harus WIB).
// Jalankan: TZ=Asia/Jakarta dart run tool/print_plan.dart
import '../lib/core/astronomy/night_third_calculator.dart';
import '../lib/core/astronomy/prayer_time_calculator.dart';
import '../lib/features/alarm/domain/entities/alarm_settings.dart';
import '../lib/features/alarm/domain/usecases/build_alarm_plan.dart';

void main() {
  const loc = GeoPoint(-7.57, 110.82);
  const calc = PrayerTimeCalculator(method: CalculationMethod.kemenag);
  final planner = BuildAlarmPlan(NightThirdCalculator(calc, loc));
  final now = DateTime(2026, 10, 29, 4, 41);
  final plan = planner(
    settings: const AlarmSettings(
      tahajudRule: BeforeFajrRule(minutesBefore: 10),
      preFajrMinutes: 15,
    ),
    localNow: now,
    horizonDays: 7,
  );
  for (final o in plan) {
    final t = o.triggerAt.toLocal();
    print('${o.id}  ${o.kind.name.padRight(8)} ${t.toString().substring(0, 16)}  ${o.mission.name}');
  }
  print('Total ${plan.length} alarm');
}

import 'package:flutter_test/flutter_test.dart';
import 'package:tahajud_subuh_companion/core/astronomy/night_third_calculator.dart';
import 'package:tahajud_subuh_companion/core/astronomy/prayer_time_calculator.dart';
import 'package:tahajud_subuh_companion/core/astronomy/qibla.dart';

String wib(DateTime utc) {
  final l = utc.add(const Duration(hours: 7));
  return '${l.hour.toString().padLeft(2, '0')}:${l.minute.toString().padLeft(2, '0')}';
}

void main() {
  const surakarta = GeoPoint(-7.57, 110.82);
  const calc = PrayerTimeCalculator(method: CalculationMethod.kemenag);

  test('Subuh Surakarta sama dengan jadwal Kemenag (sampel November 2026)', () {
    const expected = {1: '03:51', 3: '03:50', 6: '03:49', 10: '03:48', 15: '03:47', 30: '03:47'};
    expected.forEach((day, subuh) {
      expect(wib(calc.compute(surakarta, 2026, 11, day).fajr), subuh, reason: 'Nov $day');
    });
  });

  test('Maghrib dan Isya 1 November 2026', () {
    final t = calc.compute(surakarta, 2026, 11, 1);
    expect(wib(t.maghrib), '17:35');
    expect(wib(t.isha), '18:46');
  });

  test('Sepertiga malam terakhir = Subuh − durasi/3', () {
    final night = const NightThirdCalculator(calc, surakarta)
        .forEvening(DateTime(2026, 10, 29));
    expect(wib(night.maghrib), '17:34');
    expect(wib(night.fajr), '03:52');
    expect(night.duration.inMinutes, 618);
    expect(wib(night.lastThirdStart), '00:26');
    expect(night.fajr.difference(night.lastThirdStart), night.third);
    expect(night.thirdIndexAt(night.lastThirdStart), 2);
  });

  test('Aturan relatif: 10 menit sebelum Subuh', () {
    final night = const NightThirdCalculator(calc, surakarta)
        .forEvening(DateTime(2026, 10, 29));
    expect(wib(const BeforeFajrRule(minutesBefore: 10).resolve(night)), '03:42');
  });

  test('Arah kiblat dari Surakarta sekitar 294–295°', () {
    expect(qiblaBearing(-7.57, 110.82), closeTo(294.5, 1.0));
  });
}

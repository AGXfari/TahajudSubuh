Font sudah disertakan, keduanya berlisensi SIL Open Font License 1.1
(teks lisensi di OFL-*.txt):

- Plus Jakarta Sans (Tokotype) — Light, Regular, SemiBold
- Amiri — Regular

package id.tahajud.companion

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/** MethodChannel `id.tahajud.companion/alarm`: Flutter ↔ AlarmManager. */
class AlarmBridge(
    private val activity: MainActivity,
    messenger: BinaryMessenger,
) : MethodChannel.MethodCallHandler {

    private val channel = MethodChannel(messenger, "id.tahajud.companion/alarm")
    private var pendingLaunchId: Int? = null

    init {
        channel.setMethodCallHandler(this)
    }

    fun onLaunchIntent(intent: Intent?) {
        val id = intent?.getIntExtra(AlarmClockScheduler.EXTRA_ID, -1) ?: -1
        if (id < 0) return
        pendingLaunchId = id
        channel.invokeMethod("alarmLaunched", id) // jika Flutter sudah berjalan
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        val ctx = activity.applicationContext
        when (call.method) {
            "replaceAll" -> {
                AlarmClockScheduler.replaceAll(ctx, call.argument<String>("planJson") ?: "[]")
                result.success(null)
            }
            "getAlarm" -> result.success(AlarmStore.find(ctx, call.argument<Int>("id") ?: -1)?.toString())
            "takeLaunchAlarmId" -> {
                // Hanya kembalikan jika alarm itu memang masih berbunyi.
                val id = pendingLaunchId?.takeIf { it == AlarmRingService.ringingId }
                pendingLaunchId = null
                result.success(id)
            }
            "stopRinging" -> {
                sendToService(AlarmRingService.ACTION_STOP, call.argument<Int>("id") ?: -1, 0)
                activity.clearRingWindow()
                result.success(null)
            }
            "snooze" -> {
                val delay = (call.argument<Number>("delayMillis") ?: 300_000).toLong()
                sendToService(AlarmRingService.ACTION_SNOOZE, call.argument<Int>("id") ?: -1, delay)
                activity.clearRingWindow()
                result.success(null)
            }
            "checkReadiness" -> result.success(readiness())
            "openSettings" -> result.success(openSettings(call.argument<String>("page") ?: ""))
            else -> result.notImplemented()
        }
    }

    private fun sendToService(action: String, id: Int, delayMs: Long) {
        if (AlarmRingService.ringingId == null) return
        val i = Intent(activity, AlarmRingService::class.java)
            .setAction(action)
            .putExtra(AlarmClockScheduler.EXTRA_ID, id)
            .putExtra(AlarmRingService.EXTRA_DELAY_MS, delayMs)
        activity.startService(i) // aplikasi di depan: startService diizinkan
    }

    private fun readiness(): Map<String, Any> {
        val am = activity.getSystemService(AlarmManager::class.java)
        val nm = activity.getSystemService(NotificationManager::class.java)
        val pm = activity.getSystemService(PowerManager::class.java)
        return mapOf(
            "notifications" to NotificationManagerCompat.from(activity).areNotificationsEnabled(),
            "exactAlarms" to (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()),
            "fullScreenIntent" to (Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent()),
            "ignoringBatteryOptimizations" to pm.isIgnoringBatteryOptimizations(activity.packageName),
            "manufacturer" to Build.MANUFACTURER,
        )
    }

    private fun openSettings(page: String): Boolean {
        val pkg = Uri.parse("package:${activity.packageName}")
        val intent: Intent? = when (page) {
            "notifications" -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 701)
                    return true
                }
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
            }
            "exactAlarms" -> if (Build.VERSION.SDK_INT >= 31) {
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg)
            } else null
            "fullScreenIntent" -> if (Build.VERSION.SDK_INT >= 34) {
                Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg)
            } else null
            "batteryOptimization" -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)
            "oemAutostart" -> OemSettings.autostartIntent(activity)
            else -> null
        }
        return intent?.let { start(it) || start(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)) } ?: false
    }

    private fun start(intent: Intent): Boolean = runCatching {
        activity.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.isSuccess
}

package id.tahajud.companion

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {

    companion object {
        /** Intent pembuka aplikasi; [alarmId] != null berarti dibuka oleh alarm. */
        fun launchIntent(ctx: Context, alarmId: Int?): Intent =
            Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                if (alarmId != null) putExtra(AlarmClockScheduler.EXTRA_ID, alarmId)
            }
    }

    private var bridge: AlarmBridge? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        applyRingWindow(intent)
        super.onCreate(savedInstanceState)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        bridge = AlarmBridge(this, flutterEngine.dartExecutor.binaryMessenger).also {
            it.onLaunchIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyRingWindow(intent)
        bridge?.onLaunchIntent(intent)
    }

    /** Tampil di atas layar kunci, nyalakan layar, dan redupkan ke 35%. */
    private fun applyRingWindow(intent: Intent?) {
        val ringing = (intent?.getIntExtra(AlarmClockScheduler.EXTRA_ID, -1) ?: -1) >= 0
        if (!ringing) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.35f }
    }

    /** Dipanggil AlarmBridge setelah misi selesai. */
    fun clearRingWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(false)
            setTurnScreenOn(false)
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply {
            screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
    }
}

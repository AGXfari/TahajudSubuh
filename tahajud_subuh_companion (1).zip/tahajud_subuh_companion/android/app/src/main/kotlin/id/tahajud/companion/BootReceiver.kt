package id.tahajud.companion

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * AlarmManager menghapus semua alarm saat HP dimatikan. Receiver ini memasang
 * ulang dari AlarmStore tanpa menjalankan Flutter.
 *
 * LOCKED_BOOT_COMPLETED: HP baru menyala tapi belum dibuka kuncinya (Direct Boot).
 * BOOT_COMPLETED: setelah dibuka. Keduanya ditangani; menjadwalkan dua kali aman
 * karena PendingIntent dengan ID sama hanya diperbarui.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED,
            -> AlarmClockScheduler.rescheduleAll(ctx)
        }
    }
}

package id.tahajud.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.UserManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject

/**
 * Membunyikan alarm sampai misi selesai (stopRinging dari Flutter), snooze,
 * atau batas waktu 15 menit tercapai.
 *
 * Tipe FGS "systemExempted" (Android 14+) memang disediakan untuk aplikasi yang
 * memegang izin exact alarm dan butuh FGS untuk meneruskan bunyi alarm.
 */
class AlarmRingService : Service() {

    companion object {
        const val ACTION_RING = "id.tahajud.companion.RING"
        const val ACTION_STOP = "id.tahajud.companion.STOP"
        const val ACTION_SNOOZE = "id.tahajud.companion.SNOOZE"
        const val EXTRA_DELAY_MS = "delay_ms"

        private const val CHANNEL_RING = "alarm_ring"
        private const val CHANNEL_INFO = "alarm_info"
        private const val NOTIF_RING = 4201
        private const val NOTIF_MISSED = 4202
        private const val MAX_RING_MS = 15 * 60 * 1000L
        private const val FADE_STEP_MS = 500L

        /** ID alarm yang sedang berbunyi, dibaca AlarmBridge. */
        @Volatile var ringingId: Int? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var restoreAlarmVolume: Int? = null
    private var current: JSONObject? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RING -> {
                val id = intent.getIntExtra(AlarmClockScheduler.EXTRA_ID, -1)
                val occ = AlarmStore.find(this, id)
                if (occ == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                ring(occ)
            }
            ACTION_SNOOZE -> {
                val delay = intent.getLongExtra(EXTRA_DELAY_MS, 5 * 60_000L)
                current?.let { occ ->
                    val copy = AlarmStore.addSnooze(this, occ, System.currentTimeMillis() + delay)
                    AlarmClockScheduler.schedule(this, copy)
                }
                stopRinging()
            }
            ACTION_STOP -> stopRinging()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun ring(occ: JSONObject) {
        // Alarm baru menggantikan yang masih berbunyi (misal Tahajud belum dimatikan saat pra-Subuh).
        releasePlayback()
        current = occ
        val id = occ.optInt("id")
        ringingId = id

        // 1. Foreground segera (wajib < 5 detik setelah startForegroundService).
        val notification = buildRingNotification(occ)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_RING, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NOTIF_RING, notification)
        }

        // 2. Jaga CPU tetap hidup selama alarm berbunyi.
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tahajud:ring")
            .apply { acquire(MAX_RING_MS + 60_000L) }

        // 3. Audio + getar.
        ensureAlarmStreamAudible()
        startAudio(occ)
        startVibration()

        // 4. Batas waktu: jangan berbunyi selamanya.
        handler.postDelayed({ onTimeout() }, MAX_RING_MS)
    }

    private fun startAudio(occ: JSONObject) {
        val sound = occ.optString("sound", "systemDefault")
        val gradual = sound != "adzanFull"
        val fadeMs = occ.optInt("fadeInSeconds", 60).coerceIn(5, 300) * 1000L

        // Urutan cadangan: audio pilihan → nada alarm sistem → (gagal semua) getar saja.
        player = runCatching { createPlayer(soundUri(sound), gradual) }
            .recoverCatching { createPlayer(systemAlarmUri(), gradual) }
            .getOrNull()
        if (player != null && gradual) fadeIn(fadeMs)
    }

    private fun createPlayer(uri: Uri, gradual: Boolean): MediaPlayer {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM) // tetap bunyi saat mode senyap
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            val start = if (gradual) 0.05f else 1f
            mp.setVolume(start, start)
            mp.prepare()
            mp.start()
            return mp
        } catch (e: Exception) {
            mp.release()
            throw e
        }
    }

    private fun fadeIn(durationMs: Long) {
        val steps = (durationMs / FADE_STEP_MS).toInt().coerceAtLeast(1)
        var step = 0
        handler.post(object : Runnable {
            override fun run() {
                val p = player ?: return
                step++
                // Kurva kuadratik: terdengar lebih alami daripada linear.
                val v = (0.05f + 0.95f * (step.toFloat() / steps).let { it * it }).coerceAtMost(1f)
                p.setVolume(v, v)
                if (step < steps) handler.postDelayed(this, FADE_STEP_MS)
            }
        })
    }

    private fun soundUri(sound: String): Uri {
        val rawName = when (sound) {
            "adzanFull", "adzanGradual" -> "adzan_subuh"
            "murattal" -> "murattal"
            else -> null
        } ?: return systemAlarmUri()
        // getIdentifier dipakai agar proyek tetap terkompilasi sebelum file audio ditambahkan.
        val resId = resources.getIdentifier(rawName, "raw", packageName)
        return if (resId != 0) Uri.parse("android.resource://$packageName/$resId") else systemAlarmUri()
    }

    private fun systemAlarmUri(): Uri =
        RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

    /** Volume alarm minimal 60% selama berbunyi, dikembalikan setelahnya. */
    private fun ensureAlarmStreamAudible() {
        val am = getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        val now = am.getStreamVolume(AudioManager.STREAM_ALARM)
        val min = (max * 0.6f).toInt().coerceAtLeast(1)
        if (now < min) {
            restoreAlarmVolume = now
            am.setStreamVolume(AudioManager.STREAM_ALARM, min, 0)
        }
    }

    private fun startVibration() {
        val v = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator = v
        val pattern = longArrayOf(0, 600, 400, 600, 1400)
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
        @Suppress("DEPRECATION")
        v.vibrate(VibrationEffect.createWaveform(pattern, 0), attrs)
    }

    private fun buildRingNotification(occ: JSONObject): Notification {
        createChannels()
        val id = occ.optInt("id")
        val launch = PendingIntent.getActivity(
            this, id, MainActivity.launchIntent(this, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val mission = occ.optString("mission", "none")
        // Sebelum HP dibuka pertama kali setelah reboot, Flutter belum bisa berjalan:
        // sediakan tombol Matikan langsung agar pengguna tidak terjebak.
        val userLocked = !getSystemService(UserManager::class.java).isUserUnlocked

        val b = NotificationCompat.Builder(this, CHANNEL_RING)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle(occ.optString("title"))
            .setContentText(occ.optString("body"))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(launch)
            .setFullScreenIntent(launch, true)

        if (mission == "none" || userLocked) {
            b.addAction(0, "Matikan", servicePendingIntent(ACTION_STOP, id))
        } else {
            b.addAction(0, "Selesaikan misi", launch)
        }
        val snoozeLeft = occ.optInt("snoozeLimit", 0) - occ.optInt("snoozeCount", 0)
        if (snoozeLeft > 0) {
            val minutes = occ.optInt("snoozeMinutes", 5)
            b.addAction(0, "Tunda $minutes menit", servicePendingIntent(ACTION_SNOOZE, id, minutes * 60_000L))
        }
        return b.build()
    }

    private fun servicePendingIntent(action: String, id: Int, delayMs: Long = 0): PendingIntent {
        val i = Intent(this, AlarmRingService::class.java)
            .setAction(action)
            .putExtra(AlarmClockScheduler.EXTRA_ID, id)
            .putExtra(EXTRA_DELAY_MS, delayMs)
        return PendingIntent.getService(
            this, action.hashCode() xor id, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_RING, "Alarm berbunyi", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Layar alarm Tahajud dan Subuh"
                setSound(null, null) // audio diputar MediaPlayer, bukan kanal
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_INFO, "Info alarm", NotificationManager.IMPORTANCE_DEFAULT),
        )
    }

    private fun onTimeout() {
        val occ = current
        stopRinging()
        if (occ != null) {
            val n = NotificationCompat.Builder(this, CHANNEL_INFO)
                .setSmallIcon(R.drawable.ic_stat_alarm)
                .setContentTitle("Alarm tidak dimatikan")
                .setContentText("${occ.optString("title")} berbunyi 15 menit tanpa respons.")
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(NOTIF_MISSED, n)
        }
    }

    private fun stopRinging() {
        releasePlayback()
        ringingId = null
        current = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releasePlayback() {
        handler.removeCallbacksAndMessages(null)
        player?.let { p ->
            runCatching { p.stop() }
            p.release()
        }
        player = null
        vibrator?.cancel()
        vibrator = null
        restoreAlarmVolume?.let {
            getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, it, 0)
        }
        restoreAlarmVolume = null
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
    }

    override fun onDestroy() {
        releasePlayback()
        ringingId = null
        super.onDestroy()
    }
}

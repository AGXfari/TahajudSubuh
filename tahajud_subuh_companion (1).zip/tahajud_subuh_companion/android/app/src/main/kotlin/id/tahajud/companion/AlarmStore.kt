package id.tahajud.companion

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Penyimpanan rencana alarm di *device-protected storage*.
 *
 * Penting: storage ini bisa dibaca sebelum pengguna membuka kunci HP pertama kali
 * setelah reboot (Direct Boot). Tanpa ini, HP yang restart tengah malam tidak
 * akan membunyikan alarm Subuh sampai pengguna memasukkan PIN.
 */
object AlarmStore {
    private const val PREFS = "tahajud_alarm_plan"
    private const val KEY_PLAN = "plan"
    private const val KEY_SNOOZED = "snoozed"

    /** Offset ID untuk alarm hasil snooze (ID rencana selalu < 1e9). */
    const val SNOOZE_ID_OFFSET = 1_000_000_000

    private fun prefs(ctx: Context): SharedPreferences {
        val storage = ContextCompat.createDeviceProtectedStorageContext(ctx) ?: ctx
        return storage.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    fun savePlan(ctx: Context, planJson: String) {
        // commit() (sinkron) karena bisa dipanggil tepat sebelum proses dimatikan.
        prefs(ctx).edit().putString(KEY_PLAN, planJson).putString(KEY_SNOOZED, "[]").commit()
    }

    fun plan(ctx: Context): List<JSONObject> = read(ctx, KEY_PLAN)
    fun snoozed(ctx: Context): List<JSONObject> = read(ctx, KEY_SNOOZED)
    fun all(ctx: Context): List<JSONObject> = plan(ctx) + snoozed(ctx)

    fun find(ctx: Context, id: Int): JSONObject? = all(ctx).firstOrNull { it.optInt("id") == id }

    /** Membuat salinan alarm dengan waktu baru dan menyimpannya sebagai snooze. */
    fun addSnooze(ctx: Context, original: JSONObject, triggerAtMillis: Long): JSONObject {
        val baseId = original.optInt("id") % SNOOZE_ID_OFFSET
        val copy = JSONObject(original.toString()).apply {
            put("id", SNOOZE_ID_OFFSET + baseId)
            put("triggerAtMillis", triggerAtMillis)
            put("snoozeCount", original.optInt("snoozeCount", 0) + 1)
        }
        val list = snoozed(ctx).filter { it.optInt("id") != copy.optInt("id") } + copy
        prefs(ctx).edit().putString(KEY_SNOOZED, JSONArray(list).toString()).commit()
        return copy
    }

    private fun read(ctx: Context, key: String): List<JSONObject> {
        val raw = prefs(ctx).getString(key, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { arr.getJSONObject(it) }
        }.getOrDefault(emptyList())
    }
}

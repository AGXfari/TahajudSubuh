package id.tahajud.companion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Menerima alarm dari AlarmManager dan langsung menyalakan foreground service. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != AlarmClockScheduler.ACTION_FIRE) return
        val id = intent.getIntExtra(AlarmClockScheduler.EXTRA_ID, -1)
        if (id < 0) return
        // Memulai FGS dari latar belakang diizinkan karena dipicu exact alarm
        // milik aplikasi yang memegang USE_EXACT_ALARM / SCHEDULE_EXACT_ALARM.
        val svc = Intent(ctx, AlarmRingService::class.java)
            .setAction(AlarmRingService.ACTION_RING)
            .putExtra(AlarmClockScheduler.EXTRA_ID, id)
        ContextCompat.startForegroundService(ctx, svc)
        AlarmClockScheduler.warnIfHorizonLow(ctx)
    }
}

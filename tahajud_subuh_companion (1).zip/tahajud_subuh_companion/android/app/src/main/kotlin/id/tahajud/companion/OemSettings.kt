package id.tahajud.companion

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/**
 * Halaman "Autostart" / "Mulai otomatis" milik ROM pihak ketiga. Tanpa izin ini,
 * MIUI/HyperOS, ColorOS, dan FuntouchOS bisa membatalkan alarm aplikasi saat
 * aplikasi di-swipe dari Recents. Daftar komponen mengikuti dontkillmyapp.com
 * dan perlu diuji ulang di tiap versi ROM.
 */
object OemSettings {
    private val candidates = mapOf(
        "xiaomi" to listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
        ),
        "oppo" to listOf(
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
        ),
        "vivo" to listOf(
            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
        ),
        "huawei" to listOf(
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
        ),
    )

    private val aliases = mapOf(
        "redmi" to "xiaomi", "poco" to "xiaomi",
        "realme" to "oppo", "oneplus" to "oppo",
        "iqoo" to "vivo", "honor" to "huawei",
    )

    fun autostartIntent(ctx: Context): Intent? {
        val brand = Build.MANUFACTURER.lowercase().let { aliases[it] ?: it }
        return candidates[brand].orEmpty()
            .map { Intent().setComponent(it) }
            .firstOrNull { ctx.packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY) != null }
    }
}

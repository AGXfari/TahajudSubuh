package id.tahajud.companion

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Memasang alarm dengan AlarmManager.setAlarmClock().
 *
 * Kenapa setAlarmClock dan bukan setExactAndAllowWhileIdle:
 * - setAlarmClock dikecualikan dari Doze dan App Standby, dan sistem keluar dari
 *   idle sedikit sebelum waktunya agar alarm tepat.
 * - Ikon alarm muncul di status bar dan layar kunci, jadi pengguna tahu alarm aktif.
 * - Tidak ada batas frekuensi seperti setExactAndAllowWhileIdle (1x per 9 menit saat Doze).
 */
object AlarmClockScheduler {
    const val ACTION_FIRE = "id.tahajud.companion.FIRE"
    const val EXTRA_ID = "alarm_id"

    fun replaceAll(ctx: Context, planJson: String) {
        // Batalkan semua yang lama (termasuk snooze), lalu pasang rencana baru.
        AlarmStore.all(ctx).forEach { cancel(ctx, it.optInt("id")) }
        AlarmStore.savePlan(ctx, planJson)
        val arr = JSONArray(planJson)
        for (i in 0 until arr.length()) schedule(ctx, arr.getJSONObject(i))
    }

    /** Dipanggil setelah reboot, update aplikasi, atau izin exact alarm berubah. */
    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        AlarmStore.all(ctx)
            .filter { it.optLong("triggerAtMillis") > now }
            .forEach { schedule(ctx, it) }
        warnIfHorizonLow(ctx)
    }

    /**
     * Rencana dibuat Flutter untuk 30 malam dan diperbarui setiap kali aplikasi
     * dibuka (termasuk saat misi alarm diselesaikan, yang terjadi tiap pagi).
     * Jika pengguna lama tidak membuka aplikasi dan sisa rencana < 5 hari,
     * tampilkan pengingat agar alarm tidak habis diam-diam.
     */
    fun warnIfHorizonLow(ctx: Context) {
        val last = AlarmStore.plan(ctx).maxOfOrNull { it.optLong("triggerAtMillis") } ?: return
        val daysLeft = ((last - System.currentTimeMillis()) / 86_400_000L).toInt()
        if (daysLeft >= 5) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("alarm_info", "Info alarm", NotificationManager.IMPORTANCE_DEFAULT),
        )
        val open = PendingIntent.getActivity(
            ctx, 0, MainActivity.launchIntent(ctx, null),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val text = if (daysLeft <= 0) "Jadwal alarm sudah habis." else "Jadwal alarm tinggal $daysLeft hari."
        nm.notify(
            4203,
            NotificationCompat.Builder(ctx, "alarm_info")
                .setSmallIcon(R.drawable.ic_stat_alarm)
                .setContentTitle(text)
                .setContentText("Buka aplikasi sekali untuk memperpanjang 30 hari ke depan.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build(),
        )
    }

    fun schedule(ctx: Context, occ: JSONObject) {
        val id = occ.optInt("id")
        val trigger = occ.optLong("triggerAtMillis")
        if (trigger <= System.currentTimeMillis()) return

        val am = ctx.getSystemService(AlarmManager::class.java)
        val fire = firePendingIntent(ctx, id, PendingIntent.FLAG_UPDATE_CURRENT)!!

        val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        if (!exactAllowed) {
            // Cadangan jika izin dicabut: tetap bangun dari Doze, tapi bisa meleset beberapa menit.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, fire)
            return
        }
        val showIntent = PendingIntent.getActivity(
            ctx, id, MainActivity.launchIntent(ctx, null),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(trigger, showIntent), fire)
    }

    fun cancel(ctx: Context, id: Int) {
        val pi = firePendingIntent(ctx, id, PendingIntent.FLAG_NO_CREATE) ?: return
        ctx.getSystemService(AlarmManager::class.java).cancel(pi)
        pi.cancel()
    }

    private fun firePendingIntent(ctx: Context, id: Int, flag: Int): PendingIntent? {
        val intent = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra(EXTRA_ID, id)
        return PendingIntent.getBroadcast(ctx, id, intent, flag or PendingIntent.FLAG_IMMUTABLE)
    }
}

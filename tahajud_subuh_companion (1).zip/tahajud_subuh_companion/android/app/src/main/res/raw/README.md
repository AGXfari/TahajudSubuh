Letakkan file audio di folder ini (nama huruf kecil, tanpa spasi):

- `adzan_subuh.ogg` — adzan Subuh lengkap dengan lafaz "ash-shalatu khairum minan naum"
- `murattal.ogg` — lantunan ayat untuk alarm Tahajud

Pastikan lisensi rekaman mengizinkan distribusi di aplikasi. Jika file tidak ada,
AlarmRingService otomatis memakai nada alarm sistem.

# Tahajud & Subuh Companion

Kode pendamping PRD. Isinya inti yang paling menentukan: mesin waktu salat offline,
kalkulator sepertiga malam terakhir, penjadwal alarm Android, dan Dasbor Malam.

## Membuat APK

**Tanpa komputer berisi Flutter (GitHub Actions):** buat repo GitHub, unggah
`tahajud_subuh_companion.zip` ke akar repo, lalu buat file
`.github/workflows/build-apk.yml` dengan isi file yang sama di paket ini.
Build berjalan otomatis (sekitar 10 menit); APK ada di tab Actions → Artifacts.

**Di komputer sendiri (Flutter 3.44+, Android SDK, JDK 17):**

```bash
bash tool/prepare_android.sh   # lengkapi kerangka Android dari template Flutter
flutter pub get
flutter test
flutter build apk --release    # hasil: build/app/outputs/flutter-apk/app-release.apk
```

Audio adzan/murattal opsional (`android/app/src/main/res/raw/README.md`);
tanpa file itu alarm memakai nada alarm sistem.

## Validasi algoritma tanpa Flutter

```bash
dart run tool/validate_surakarta.dart          # bandingkan dengan jadwal Kemenag Nov 2026
TZ=Asia/Jakarta dart run tool/print_plan.dart  # cetak rencana alarm 7 malam
```

Hasil di Kota Surakarta (−7,57; 110,82), November 2026: Subuh, Maghrib, Isya sama
persis 30/30 hari; Dzuhur 29/30; Ashar 27/30; semua selisih maksimal 1 menit.

## Peta folder

```
lib/
  main.dart, app.dart
  core/
    astronomy/   prayer_time_calculator.dart, night_third_calculator.dart, qibla.dart  (Dart murni)
    storage/     local_store.dart (Hive CE)
    location/    location_service.dart
    theme/       night_palette.dart, night_theme.dart
    widgets/     red_tint_overlay.dart
  features/
    alarm/
      domain/    entities/, repositories/alarm_scheduler.dart, usecases/build_alarm_plan.dart, refresh_alarm_plan.dart
      data/      native_alarm_scheduler.dart, alarm_permission_service.dart
      presentation/ ring_page.dart (misi matematika)
    dashboard/
      presentation/ dashboard_page.dart, dashboard_view_model.dart, widgets/
android/app/src/main/
  AndroidManifest.xml
  kotlin/id/tahajud/companion/
    MainActivity.kt, AlarmBridge.kt, AlarmClockScheduler.kt, AlarmReceiver.kt,
    AlarmRingService.kt, BootReceiver.kt, AlarmStore.kt, OemSettings.kt
test/astronomy_test.dart
tool/validate_surakarta.dart, tool/print_plan.dart, tool/prepare_android.sh
.github/workflows/build-apk.yml
```

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'core/storage/local_store.dart';
import 'features/alarm/data/native_alarm_scheduler.dart';
import 'features/dashboard/presentation/dashboard_view_model.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  final store = await LocalStore.open();
  final launchAlarmId = await NativeAlarmScheduler().takeLaunchAlarmId();

  runApp(
    ProviderScope(
      overrides: [localStoreProvider.overrideWithValue(store)],
      child: TahajudApp(launchAlarmId: launchAlarmId),
    ),
  );
}

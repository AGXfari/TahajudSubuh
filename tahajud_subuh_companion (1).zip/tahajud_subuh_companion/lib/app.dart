import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme/night_theme.dart';
import 'core/widgets/red_tint_overlay.dart';
import 'features/alarm/data/native_alarm_scheduler.dart';
import 'features/alarm/presentation/ring_page.dart';
import 'features/dashboard/presentation/dashboard_page.dart';
import 'features/dashboard/presentation/dashboard_view_model.dart';

final navigatorKey = GlobalKey<NavigatorState>();

class TahajudApp extends ConsumerStatefulWidget {
  const TahajudApp({super.key, this.launchAlarmId});

  /// Diisi jika aplikasi dibuka oleh full-screen intent alarm.
  final int? launchAlarmId;

  @override
  ConsumerState<TahajudApp> createState() => _TahajudAppState();
}

class _TahajudAppState extends ConsumerState<TahajudApp> {
  @override
  void initState() {
    super.initState();
    // Alarm berbunyi saat aplikasi sudah terbuka → native memanggil alarmLaunched.
    const MethodChannel(NativeAlarmScheduler.channelName).setMethodCallHandler((call) async {
      if (call.method == 'alarmLaunched') {
        navigatorKey.currentState?.pushNamed('/ring', arguments: call.arguments as int);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final redTint = ref.watch(dashboardProvider.select((s) => s.redTint));
    return MaterialApp(
      title: 'Tahajud & Subuh',
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      theme: buildNightTheme(),
      themeMode: ThemeMode.dark,
      locale: const Locale('id'),
      builder: (context, child) => RedTintOverlay(enabled: redTint, child: child!),
      initialRoute: widget.launchAlarmId != null ? '/ring' : '/',
      onGenerateInitialRoutes: (initial) => [
        if (initial == '/ring' && widget.launchAlarmId != null)
          MaterialPageRoute(builder: (_) => RingPage(alarmId: widget.launchAlarmId!))
        else
          MaterialPageRoute(builder: (_) => const DashboardPage()),
      ],
      onGenerateRoute: (s) => switch (s.name) {
        '/' => MaterialPageRoute(builder: (_) => const DashboardPage()),
        '/ring' => MaterialPageRoute(builder: (_) => RingPage(alarmId: s.arguments! as int)),
        // Fitur P1: Jurnal, Kiblat, Panduan, Pengaturan menyusul di v1.1.
        _ => MaterialPageRoute(builder: (_) => _ComingSoon(name: s.name ?? '')),
      },
    );
  }
}

class _ComingSoon extends StatelessWidget {
  const _ComingSoon({required this.name});
  final String name;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(),
        body: Center(child: Text('Halaman $name hadir di versi 1.1')),
      );
}

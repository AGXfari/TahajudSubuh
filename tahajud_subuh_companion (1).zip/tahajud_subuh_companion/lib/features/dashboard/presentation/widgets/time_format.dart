/// Format waktu Indonesia tanpa dependensi intl (data lokal, offline).
library;

const _days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
const _months = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
];

/// 03.47 (PUEBI memakai titik untuk jam).
String hm(DateTime t) {
  final l = t.toLocal();
  return '${l.hour.toString().padLeft(2, '0')}.${l.minute.toString().padLeft(2, '0')}';
}

/// Kamis, 29 Oktober
String dayDate(DateTime t) =>
    '${_days.elementAt(t.weekday - 1)}, ${t.day} ${_months.elementAt(t.month - 1)}';

/// 2 j 14 m · 47 m · kurang dari 1 m
String countdown(Duration d) {
  if (d.inMinutes < 1) return 'kurang dari 1 m';
  final h = d.inHours;
  final m = d.inMinutes % 60;
  return h > 0 ? '$h j $m m' : '$m m';
}

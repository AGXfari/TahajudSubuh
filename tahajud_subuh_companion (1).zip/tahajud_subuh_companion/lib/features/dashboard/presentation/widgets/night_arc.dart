import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../../../core/astronomy/night_third_calculator.dart';
import '../../../../core/theme/night_palette.dart';
import 'time_format.dart';

/// Busur malam: Maghrib (kiri) → Subuh (kanan), dibagi tiga.
/// Sepertiga terakhir menyala amber; titik bulan menandai waktu sekarang.
class NightArc extends StatelessWidget {
  const NightArc({super.key, required this.night, required this.now});

  final NightThirds night;
  final DateTime now;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final nowUtc = now.toUtc();
    final started = !nowUtc.isBefore(night.maghrib);
    final progress = night.progressAt(nowUtc);
    final label = 'Malam ${hm(night.maghrib)} sampai ${hm(night.fajr)}. '
        'Sepertiga terakhir mulai ${hm(night.lastThirdStart)}.';

    return Semantics(
      label: label,
      excludeSemantics: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 132,
            child: CustomPaint(
              painter: _ArcPainter(
                progress: progress,
                showMoon: started,
                lastThirdActive: night.thirdIndexAt(nowUtc) == 2,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _End(time: hm(night.maghrib), name: 'Maghrib', style: t.bodySmall!),
              const Spacer(),
              _End(
                time: hm(night.fajr),
                name: 'Subuh',
                style: t.bodySmall!,
                alignEnd: true,
                accent: true,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _End extends StatelessWidget {
  const _End({
    required this.time,
    required this.name,
    required this.style,
    this.alignEnd = false,
    this.accent = false,
  });

  final String time;
  final String name;
  final TextStyle style;
  final bool alignEnd;
  final bool accent;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Text(time,
              style: style.copyWith(
                fontSize: 15,
                color: accent ? NightPalette.fajar : NightPalette.perkamen,
              )),
          Text(name, style: style.copyWith(color: NightPalette.bara)),
        ],
      );
}

class _ArcPainter extends CustomPainter {
  _ArcPainter({
    required this.progress,
    required this.showMoon,
    required this.lastThirdActive,
  });

  final double progress;
  final bool showMoon;
  final bool lastThirdActive;

  // Kurva Bézier kuadratik: lengkung langit yang landai.
  late Offset _p0, _p1, _p2;

  Offset _at(double t) {
    final u = 1 - t;
    return _p0 * (u * u) + _p1 * (2 * u * t) + _p2 * (t * t);
  }

  Path _segment(double from, double to) {
    const steps = 48;
    final path = Path()..moveTo(_at(from).dx, _at(from).dy);
    for (var i = 1; i <= steps; i++) {
      final p = _at(from + (to - from) * i / steps);
      path.lineTo(p.dx, p.dy);
    }
    return path;
  }

  @override
  void paint(Canvas canvas, Size size) {
    const inset = 10.0;
    _p0 = Offset(inset, size.height - 12);
    _p2 = Offset(size.width - inset, size.height - 12);
    _p1 = Offset(size.width / 2, -size.height * 0.55);

    final quiet = Paint()
      ..color = NightPalette.bara.withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;

    // Sepertiga pertama dan kedua: garis tenang.
    canvas.drawPath(_segment(0, 2 / 3), quiet);

    // Sepertiga terakhir: cahaya lentera, lebih terang saat sedang berlangsung.
    final glow = Paint()
      ..color = NightPalette.lentera.withValues(alpha: lastThirdActive ? 0.45 : 0.22)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    final core = Paint()
      ..color = NightPalette.lentera
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    final last = _segment(2 / 3, 1);
    canvas.drawPath(last, glow);
    canvas.drawPath(last, core);

    // Penanda batas sepertiga: garis pendek tegak lurus.
    final tick = Paint()
      ..color = NightPalette.bara
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;
    for (final t in const [1 / 3, 2 / 3]) {
      final p = _at(t);
      canvas.drawLine(p.translate(0, -7), p.translate(0, 7), tick);
    }

    // Bulan: titik perkamen dengan halo; halo amber di sepertiga terakhir.
    if (showMoon) {
      final m = _at(progress);
      canvas.drawCircle(
        m,
        14,
        Paint()
          ..color = (lastThirdActive ? NightPalette.lentera : NightPalette.perkamen)
              .withValues(alpha: 0.18)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(m, 6, Paint()..color = NightPalette.perkamen);
      // Sabit: lingkaran hitam digeser memotong bulan.
      canvas.drawCircle(m.translate(2.6, -1.6), 5, Paint()..color = NightPalette.malam);
    }

    // Lantai cakrawala yang sangat samar, memberi pijakan visual.
    final horizon = Paint()
      ..shader = ui.Gradient.linear(
        Offset(0, size.height - 12),
        Offset(size.width, size.height - 12),
        [
          NightPalette.bara.withValues(alpha: 0),
          NightPalette.bara.withValues(alpha: 0.25),
          NightPalette.fajar.withValues(alpha: 0.35),
        ],
        const [0, 0.5, 1],
      )
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, size.height - 12), Offset(size.width, size.height - 12), horizon);
  }

  @override
  bool shouldRepaint(_ArcPainter old) =>
      old.progress != progress ||
      old.showMoon != showMoon ||
      old.lastThirdActive != lastThirdActive;
}

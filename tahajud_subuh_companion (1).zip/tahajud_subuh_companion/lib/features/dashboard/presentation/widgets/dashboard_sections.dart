import 'package:flutter/material.dart';

import '../../../../core/storage/local_store.dart';
import '../../../../core/theme/night_palette.dart';
import '../../../alarm/domain/entities/alarm_settings.dart';
import '../dashboard_view_model.dart';
import 'time_format.dart';

/// Hitung mundur ke alarm berikutnya, atau status sepertiga terakhir.
class CountdownBlock extends StatelessWidget {
  const CountdownBlock({super.key, required this.state});
  final DashboardState state;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final night = state.night!;
    final now = state.now.toUtc();
    final next = state.nextAlarm;

    final (String lead, String big) = switch ((state.inLastThird, next)) {
      (true, _) => ('Sepertiga terakhir sedang berlangsung. Subuh dalam',
          countdown(night.fajr.difference(now))),
      (false, final AlarmRowData n) => ('${n.label} dalam', countdown(n.time!.difference(now))),
      (false, null) => ('Semua alarm malam ini nonaktif', '—'),
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(lead, style: t.bodyLarge!.copyWith(color: NightPalette.bara)),
        const SizedBox(height: 4),
        Text(big, style: t.displayMedium),
        const SizedBox(height: 12),
        Text(
          'Sepertiga terakhir ${hm(night.lastThirdStart)}–${hm(night.fajr)}',
          style: t.bodyMedium!.copyWith(color: NightPalette.lentera),
        ),
      ],
    );
  }
}

class AlarmRow extends StatelessWidget {
  const AlarmRow({super.key, required this.row, required this.onChanged});
  final AlarmRowData row;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final dim = !row.enabled || row.time == null;
    final color = dim ? NightPalette.bara : NightPalette.perkamen;
    return MergeSemantics(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(row.label, style: t.titleMedium!.copyWith(color: color)),
                  if (row.note != null)
                    Text(row.note!, style: t.bodySmall!.copyWith(color: NightPalette.bara)),
                ],
              ),
            ),
            Text(
              row.time == null ? '—' : hm(row.time!),
              style: t.headlineSmall!.copyWith(
                color: row.kind == AlarmKind.fajr && !dim ? NightPalette.fajar : color,
              ),
            ),
            const SizedBox(width: 16),
            Switch(value: row.enabled, onChanged: row.time == null ? null : onChanged),
          ],
        ),
      ),
    );
  }
}

/// Jejak 7 hari: titik penuh = Subuh tepat waktu/berjamaah, cincin = belum/terlewat,
/// titik kecil dalam cincin = uzur (tidak memutus rangkaian).
class StreakStrip extends StatelessWidget {
  const StreakStrip({super.key, required this.week, required this.streak});
  final List<DayRecord> week;
  final int streak;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final kept = week.where((d) => d.fajr == FajrStatus.onTime || d.fajr == FajrStatus.jamaah).length;
    return Semantics(
      label: 'Subuh tepat waktu $kept dari 7 hari terakhir. Rangkaian $streak hari.',
      excludeSemantics: true,
      child: Row(
        children: [
          for (final d in week) ...[_Dot(record: d), const SizedBox(width: 10)],
          const Spacer(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('$streak hari', style: t.titleMedium),
              Text('rangkaian Subuh', style: t.bodySmall!.copyWith(color: NightPalette.bara)),
            ],
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot({required this.record});
  final DayRecord record;

  @override
  Widget build(BuildContext context) {
    final f = record.fajr;
    final filled = f == FajrStatus.onTime || f == FajrStatus.jamaah;
    return Container(
      width: 14,
      height: 14,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: filled ? NightPalette.lentera : null,
        border: filled ? null : Border.all(color: NightPalette.bara, width: 1.5),
      ),
      child: f == FajrStatus.uzur
          ? Center(
              child: Container(
                width: 4,
                height: 4,
                decoration: const BoxDecoration(shape: BoxShape.circle, color: NightPalette.fajar),
              ),
            )
          : null,
    );
  }
}

/// Peringatan saat izin kurang: alarm tidak boleh gagal diam-diam.
class ReadinessBanner extends StatelessWidget {
  const ReadinessBanner({super.key, required this.onFix});
  final VoidCallback onFix;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
      decoration: BoxDecoration(
        color: NightPalette.arang,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: NightPalette.lentera.withValues(alpha: 0.5)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Alarm belum bisa tampil di layar kunci. Satu izin lagi diperlukan.',
              style: t.bodyLarge,
            ),
          ),
          TextButton(onPressed: onFix, child: const Text('Beri izin')),
        ],
      ),
    );
  }
}

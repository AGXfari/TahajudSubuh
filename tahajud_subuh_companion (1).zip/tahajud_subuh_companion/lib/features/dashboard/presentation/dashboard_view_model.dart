import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/astronomy/night_third_calculator.dart';
import '../../../core/astronomy/prayer_time_calculator.dart';
import '../../../core/location/location_service.dart';
import '../../../core/storage/local_store.dart';
import '../../alarm/data/alarm_permission_service.dart';
import '../../alarm/data/native_alarm_scheduler.dart';
import '../../alarm/domain/entities/alarm_settings.dart';
import '../../alarm/domain/repositories/alarm_scheduler.dart';
import '../../alarm/domain/usecases/refresh_alarm_plan.dart';

// ---- Dependensi (di-override di main.dart dan di test) ----------------------

final localStoreProvider = Provider<LocalStore>(
  (_) => throw UnimplementedError('Override di main() setelah LocalStore.open()'),
);
final alarmSchedulerProvider = Provider<AlarmScheduler>((_) => NativeAlarmScheduler());
final permissionServiceProvider = Provider((_) => const AlarmPermissionService());
final locationServiceProvider = Provider((_) => const LocationService());

// ---- State ------------------------------------------------------------------

/// Satu baris alarm di dasbor.
class AlarmRowData {
  const AlarmRowData({
    required this.kind,
    required this.label,
    required this.time,
    required this.enabled,
    this.note,
  });
  final AlarmKind kind;
  final String label;
  final DateTime? time; // null = tidak valid malam ini (misal jam tetap setelah Subuh)
  final bool enabled;
  final String? note;
}

class DashboardState {
  const DashboardState({
    required this.now,
    required this.settings,
    this.location,
    this.night,
    this.rows = const [],
    this.week = const [],
    this.streak = 0,
    this.redTint = false,
    this.readiness,
  });

  final DateTime now;
  final AlarmSettings settings;
  final SavedLocation? location;
  final NightThirds? night;
  final List<AlarmRowData> rows;
  final List<DayRecord> week;
  final int streak;
  final bool redTint;
  final AlarmReadiness? readiness;

  bool get needsLocation => location == null;

  /// Alarm aktif berikutnya, untuk hitung mundur.
  AlarmRowData? get nextAlarm {
    final upcoming = rows
        .where((r) => r.enabled && r.time != null && r.time!.isAfter(now.toUtc()))
        .toList()
      ..sort((a, b) => a.time!.compareTo(b.time!));
    return upcoming.firstOrNull;
  }

  bool get inLastThird => night?.thirdIndexAt(now.toUtc()) == 2;

  DashboardState copyWith({
    DateTime? now,
    AlarmSettings? settings,
    SavedLocation? location,
    NightThirds? night,
    List<AlarmRowData>? rows,
    List<DayRecord>? week,
    int? streak,
    bool? redTint,
    AlarmReadiness? readiness,
  }) =>
      DashboardState(
        now: now ?? this.now,
        settings: settings ?? this.settings,
        location: location ?? this.location,
        night: night ?? this.night,
        rows: rows ?? this.rows,
        week: week ?? this.week,
        streak: streak ?? this.streak,
        redTint: redTint ?? this.redTint,
        readiness: readiness ?? this.readiness,
      );
}

// ---- ViewModel ----------------------------------------------------------------

final dashboardProvider =
    NotifierProvider<DashboardViewModel, DashboardState>(DashboardViewModel.new);

class DashboardViewModel extends Notifier<DashboardState> {
  Timer? _ticker;
  AlarmReadiness? _readiness;

  LocalStore get _store => ref.read(localStoreProvider);

  @override
  DashboardState build() {
    // Detak 30 detik cukup untuk hitung mundur menit dan posisi bulan.
    _ticker = Timer.periodic(const Duration(seconds: 30), (_) => _tick());
    ref.onDispose(() => _ticker?.cancel());
    Future.microtask(_refreshExternal);
    return _compute(DateTime.now());
  }

  DashboardState _compute(DateTime now) {
    final store = _store;
    final settings = store.alarmSettings;
    final loc = store.location;
    final today = DateTime(now.year, now.month, now.day);
    final base = DashboardState(
      now: now,
      settings: settings,
      location: loc,
      week: store.lastDays(today, 7),
      streak: store.fajrStreak(today),
      redTint: store.redTint,
      readiness: _readiness,
    );
    if (loc == null) return base;

    final nights = NightThirdCalculator(PrayerTimeCalculator(method: store.method), loc.geo);
    final night = nights.currentOrNext(now);
    return base.copyWith(night: night, rows: _rows(night, settings));
  }

  List<AlarmRowData> _rows(NightThirds night, AlarmSettings s) {
    DateTime? tahajud;
    String? note;
    try {
      tahajud = s.tahajudRule.resolve(night);
    } on TahajudRuleError catch (e) {
      note = e.message;
    }
    return [
      AlarmRowData(
        kind: AlarmKind.tahajud,
        label: 'Tahajud',
        time: tahajud,
        enabled: s.tahajudEnabled && !s.uzurMode,
        note: note,
      ),
      AlarmRowData(
        kind: AlarmKind.preFajr,
        label: 'Pra-Subuh',
        time: night.fajr.subtract(Duration(minutes: s.preFajrMinutes)),
        enabled: s.preFajrEnabled && !s.uzurMode,
      ),
      AlarmRowData(
        kind: AlarmKind.fajr,
        label: 'Subuh',
        time: night.fajr,
        enabled: s.fajrEnabled && !s.uzurMode,
      ),
    ];
  }

  void _tick() {
    final now = DateTime.now();
    final night = state.night;
    // Lewat Subuh → pindah ke malam berikutnya; selain itu cukup perbarui jam.
    if (night != null && !now.toUtc().isBefore(night.fajr)) {
      state = _compute(now);
    } else {
      state = state.copyWith(now: now);
    }
  }

  Future<void> _refreshExternal() async {
    _readiness = await ref.read(permissionServiceProvider).check();
    state = state.copyWith(readiness: _readiness);
    await _replan();
  }

  Future<void> _replan() async {
    final loc = _store.location;
    if (loc == null) return;
    await RefreshAlarmPlan(ref.read(alarmSchedulerProvider)).call(
      location: loc.geo,
      method: _store.method,
      settings: _store.alarmSettings,
    );
  }

  // ---- Aksi dari UI -----------------------------------------------------------

  Future<bool> useCurrentLocation() async {
    final loc = await ref.read(locationServiceProvider).current();
    if (loc == null) return false;
    await _store.saveLocation(loc);
    state = _compute(DateTime.now());
    await _replan();
    return true;
  }

  Future<void> setAlarmEnabled(AlarmKind kind, bool enabled) async {
    final s = _store.alarmSettings;
    final next = switch (kind) {
      AlarmKind.tahajud => s.copyWith(tahajudEnabled: enabled),
      AlarmKind.preFajr => s.copyWith(preFajrEnabled: enabled),
      AlarmKind.fajr => s.copyWith(fajrEnabled: enabled),
      AlarmKind.snooze => s,
    };
    await _store.saveAlarmSettings(next);
    state = _compute(state.now);
    await _replan();
  }

  Future<void> toggleRedTint() async {
    await _store.saveRedTint(!state.redTint);
    state = state.copyWith(redTint: !state.redTint);
  }

  /// Membuka layar izin pertama yang belum terpenuhi, lalu cek ulang.
  Future<void> fixReadiness() async {
    final r = state.readiness;
    final svc = ref.read(permissionServiceProvider);
    if (r == null) return;
    final page = !r.notifications
        ? AlarmSettingsPage.notifications
        : !r.exactAlarms
            ? AlarmSettingsPage.exactAlarms
            : !r.fullScreenIntent
                ? AlarmSettingsPage.fullScreenIntent
                : r.needsAutostartGuide
                    ? AlarmSettingsPage.oemAutostart
                    : AlarmSettingsPage.batteryOptimization;
    await svc.open(page);
  }

  /// Dipanggil saat aplikasi kembali ke depan (AppLifecycleState.resumed).
  Future<void> onResume() async {
    state = _compute(DateTime.now());
    await _refreshExternal();
  }
}

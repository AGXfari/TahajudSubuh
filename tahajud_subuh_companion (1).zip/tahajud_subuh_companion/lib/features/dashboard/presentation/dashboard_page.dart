import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/night_palette.dart';
import 'dashboard_view_model.dart';
import 'widgets/dashboard_sections.dart';
import 'widgets/night_arc.dart';
import 'widgets/time_format.dart';

/// Dasbor Malam: satu layar yang menjawab "kapan aku harus bangun malam ini?".
class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    // Kembali dari layar izin sistem → cek ulang izin dan perpanjang jadwal.
    if (s == AppLifecycleState.resumed) ref.read(dashboardProvider.notifier).onResume();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(dashboardProvider);
    final vm = ref.read(dashboardProvider.notifier);
    final t = Theme.of(context).textTheme;

    return Scaffold(
      body: SafeArea(
        child: state.needsLocation
            ? _LocationEmpty(onUseLocation: vm.useCurrentLocation)
            : ListView(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
                children: [
                  _Header(
                    place: state.location!.label,
                    date: dayDate(state.now),
                    redTint: state.redTint,
                    onToggleTint: vm.toggleRedTint,
                  ),
                  const SizedBox(height: 28),
                  NightArc(night: state.night!, now: state.now),
                  const SizedBox(height: 32),
                  CountdownBlock(state: state),
                  if (state.readiness != null && !state.readiness!.isReady) ...[
                    const SizedBox(height: 24),
                    ReadinessBanner(onFix: vm.fixReadiness),
                  ],
                  const SizedBox(height: 36),
                  Text('Alarm malam ini', style: t.bodySmall!.copyWith(color: NightPalette.bara)),
                  const SizedBox(height: 4),
                  for (final row in state.rows)
                    AlarmRow(row: row, onChanged: (on) => vm.setAlarmEnabled(row.kind, on)),
                  if (state.settings.uzurMode) ...[
                    const SizedBox(height: 8),
                    Text(
                      'Mode uzur aktif. Alarm ditunda sampai kamu mematikannya di Pengaturan.',
                      style: t.bodySmall!.copyWith(color: NightPalette.fajar),
                    ),
                  ],
                  const SizedBox(height: 32),
                  StreakStrip(week: state.week, streak: state.streak),
                ],
              ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (i) {
          // Rute fitur P1 (Jurnal, Kiblat, Panduan) didaftarkan di app.dart.
          const routes = ['/', '/jurnal', '/kiblat', '/panduan'];
          if (i != 0) Navigator.of(context).pushNamed(routes.elementAt(i));
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.nightlight_round), label: 'Malam'),
          NavigationDestination(icon: Icon(Icons.edit_calendar_outlined), label: 'Jurnal'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), label: 'Kiblat'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Panduan'),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.place,
    required this.date,
    required this.redTint,
    required this.onToggleTint,
  });

  final String place;
  final String date;
  final bool redTint;
  final VoidCallback onToggleTint;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(place, style: t.titleMedium, overflow: TextOverflow.ellipsis),
              Text(date, style: t.bodySmall!.copyWith(color: NightPalette.bara)),
            ],
          ),
        ),
        IconButton(
          tooltip: redTint ? 'Matikan filter merah' : 'Nyalakan filter merah',
          onPressed: onToggleTint,
          icon: Icon(
            redTint ? Icons.visibility : Icons.visibility_outlined,
            color: redTint ? NightPalette.tint : NightPalette.bara,
          ),
        ),
        IconButton(
          tooltip: 'Pengaturan',
          onPressed: () => Navigator.of(context).pushNamed('/pengaturan'),
          icon: const Icon(Icons.tune, color: NightPalette.bara),
        ),
      ],
    );
  }
}

/// Belum ada lokasi: undangan untuk bertindak, bukan pesan kosong.
class _LocationEmpty extends StatefulWidget {
  const _LocationEmpty({required this.onUseLocation});
  final Future<bool> Function() onUseLocation;

  @override
  State<_LocationEmpty> createState() => _LocationEmptyState();
}

class _LocationEmptyState extends State<_LocationEmpty> {
  bool _busy = false;
  bool _failed = false;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Jadwal malam dihitung dari lokasimu', style: t.headlineSmall),
          const SizedBox(height: 12),
          Text(
            'Lokasi dipakai sekali untuk menghitung Maghrib, Subuh, dan sepertiga '
            'malam terakhir. Data tetap di HP ini.',
            style: t.bodyLarge!.copyWith(color: NightPalette.bara),
          ),
          if (_failed) ...[
            const SizedBox(height: 12),
            Text(
              'Lokasi tidak didapat. Nyalakan GPS atau izinkan akses lokasi, lalu coba lagi.',
              style: t.bodyLarge!.copyWith(color: NightPalette.lentera),
            ),
          ],
          const SizedBox(height: 28),
          FilledButton(
            onPressed: _busy
                ? null
                : () async {
                    setState(() => _busy = true);
                    final ok = await widget.onUseLocation();
                    if (!mounted) return;
                    setState(() {
                      _busy = false;
                      _failed = !ok;
                    });
                  },
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(56),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
            ),
            child: Text(_busy ? 'Mencari lokasi…' : 'Gunakan lokasi saat ini'),
          ),
        ],
      ),
    );
  }
}

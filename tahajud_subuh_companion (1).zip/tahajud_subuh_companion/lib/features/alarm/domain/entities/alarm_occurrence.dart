import 'alarm_settings.dart';

/// Satu kejadian alarm bertanggal. Dikirim ke native sebagai JSON.
class AlarmOccurrence {
  const AlarmOccurrence({
    required this.id,
    required this.kind,
    required this.triggerAt,
    required this.title,
    required this.body,
    required this.sound,
    required this.fadeInSeconds,
    required this.mission,
    required this.snoozeLimit,
    required this.snoozeMinutes,
  });

  /// ID stabil: yyyymmdd (tanggal Subuh) × 10 + jenis. Muat di int32.
  final int id;
  final AlarmKind kind;

  /// Instan UTC.
  final DateTime triggerAt;
  final String title;
  final String body;
  final AlarmSound sound;
  final int fadeInSeconds;
  final MissionType mission;
  final int snoozeLimit;
  final int snoozeMinutes;

  static int makeId(DateTime fajrLocal, AlarmKind kind) =>
      (fajrLocal.year * 10000 + fajrLocal.month * 100 + fajrLocal.day) * 10 +
      kind.index +
      1;

  Map<String, Object> toJson() => {
        'id': id,
        'kind': kind.name,
        'triggerAtMillis': triggerAt.millisecondsSinceEpoch,
        'title': title,
        'body': body,
        'sound': sound.name,
        'fadeInSeconds': fadeInSeconds,
        'mission': mission.name,
        'snoozeLimit': snoozeLimit,
        'snoozeMinutes': snoozeMinutes,
      };

  @override
  String toString() => '${kind.name}@${triggerAt.toLocal()}';
}

import '../../../../core/astronomy/night_third_calculator.dart';

enum AlarmKind { tahajud, preFajr, fajr, snooze }

enum MissionType { none, math, quiz, shake, qr }

enum AlarmSound { adzanFull, adzanGradual, murattal, systemDefault }

/// Pengaturan alarm milik pengguna. Disimpan sebagai JSON di Hive.
class AlarmSettings {
  const AlarmSettings({
    this.tahajudEnabled = true,
    this.tahajudRule = const LastThirdRule(),
    this.preFajrEnabled = true,
    this.preFajrMinutes = 15,
    this.fajrEnabled = true,
    this.tahajudSound = AlarmSound.murattal,
    this.fajrSound = AlarmSound.adzanGradual,
    this.fadeInSeconds = 60,
    this.tahajudMission = MissionType.math,
    this.fajrMission = MissionType.shake,
    this.snoozeLimit = 1,
    this.snoozeMinutes = 5,
    this.uzurMode = false,
  })  : assert(preFajrMinutes >= 10 && preFajrMinutes <= 30),
        assert(snoozeLimit >= 0 && snoozeLimit <= 3);

  final bool tahajudEnabled;
  final TahajudRule tahajudRule;
  final bool preFajrEnabled;
  final int preFajrMinutes;
  final bool fajrEnabled;
  final AlarmSound tahajudSound;
  final AlarmSound fajrSound;
  final int fadeInSeconds;
  final MissionType tahajudMission;
  final MissionType fajrMission;
  final int snoozeLimit;
  final int snoozeMinutes;

  /// Masa uzur (haid, nifas, sakit, safar): semua alarm ditunda.
  final bool uzurMode;

  AlarmSettings copyWith({
    bool? tahajudEnabled,
    TahajudRule? tahajudRule,
    bool? preFajrEnabled,
    int? preFajrMinutes,
    bool? fajrEnabled,
    AlarmSound? tahajudSound,
    AlarmSound? fajrSound,
    int? fadeInSeconds,
    MissionType? tahajudMission,
    MissionType? fajrMission,
    int? snoozeLimit,
    int? snoozeMinutes,
    bool? uzurMode,
  }) =>
      AlarmSettings(
        tahajudEnabled: tahajudEnabled ?? this.tahajudEnabled,
        tahajudRule: tahajudRule ?? this.tahajudRule,
        preFajrEnabled: preFajrEnabled ?? this.preFajrEnabled,
        preFajrMinutes: preFajrMinutes ?? this.preFajrMinutes,
        fajrEnabled: fajrEnabled ?? this.fajrEnabled,
        tahajudSound: tahajudSound ?? this.tahajudSound,
        fajrSound: fajrSound ?? this.fajrSound,
        fadeInSeconds: fadeInSeconds ?? this.fadeInSeconds,
        tahajudMission: tahajudMission ?? this.tahajudMission,
        fajrMission: fajrMission ?? this.fajrMission,
        snoozeLimit: snoozeLimit ?? this.snoozeLimit,
        snoozeMinutes: snoozeMinutes ?? this.snoozeMinutes,
        uzurMode: uzurMode ?? this.uzurMode,
      );

  Map<String, Object> toJson() => {
        'tahajudEnabled': tahajudEnabled,
        'tahajudRule': tahajudRule.toJson(),
        'preFajrEnabled': preFajrEnabled,
        'preFajrMinutes': preFajrMinutes,
        'fajrEnabled': fajrEnabled,
        'tahajudSound': tahajudSound.name,
        'fajrSound': fajrSound.name,
        'fadeInSeconds': fadeInSeconds,
        'tahajudMission': tahajudMission.name,
        'fajrMission': fajrMission.name,
        'snoozeLimit': snoozeLimit,
        'snoozeMinutes': snoozeMinutes,
        'uzurMode': uzurMode,
      };

  factory AlarmSettings.fromJson(Map<String, Object?> j) {
    const d = AlarmSettings();
    T pick<T extends Enum>(List<T> values, Object? v, T fallback) =>
        values.firstWhere((e) => e.name == v, orElse: () => fallback);
    return AlarmSettings(
      tahajudEnabled: j['tahajudEnabled'] as bool? ?? d.tahajudEnabled,
      tahajudRule: j['tahajudRule'] is Map
          ? TahajudRule.fromJson((j['tahajudRule'] as Map).cast<String, Object?>())
          : d.tahajudRule,
      preFajrEnabled: j['preFajrEnabled'] as bool? ?? d.preFajrEnabled,
      preFajrMinutes: j['preFajrMinutes'] as int? ?? d.preFajrMinutes,
      fajrEnabled: j['fajrEnabled'] as bool? ?? d.fajrEnabled,
      tahajudSound: pick(AlarmSound.values, j['tahajudSound'], d.tahajudSound),
      fajrSound: pick(AlarmSound.values, j['fajrSound'], d.fajrSound),
      fadeInSeconds: j['fadeInSeconds'] as int? ?? d.fadeInSeconds,
      tahajudMission:
          pick(MissionType.values, j['tahajudMission'], d.tahajudMission),
      fajrMission: pick(MissionType.values, j['fajrMission'], d.fajrMission),
      snoozeLimit: j['snoozeLimit'] as int? ?? d.snoozeLimit,
      snoozeMinutes: j['snoozeMinutes'] as int? ?? d.snoozeMinutes,
      uzurMode: j['uzurMode'] as bool? ?? d.uzurMode,
    );
  }
}

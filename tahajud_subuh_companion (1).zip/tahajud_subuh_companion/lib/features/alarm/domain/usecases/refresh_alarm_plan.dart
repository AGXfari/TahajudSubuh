import '../../../../core/astronomy/night_third_calculator.dart';
import '../../../../core/astronomy/prayer_time_calculator.dart';
import '../entities/alarm_occurrence.dart';
import '../entities/alarm_settings.dart';
import '../repositories/alarm_scheduler.dart';
import 'build_alarm_plan.dart';

/// Menghitung ulang 30 malam ke depan dan menyerahkannya ke penjadwal native.
///
/// Dipanggil saat: aplikasi dibuka, pengaturan/lokasi berubah, dan setelah misi
/// alarm selesai. Karena misi diselesaikan di aplikasi setiap pagi, rencana
/// praktis selalu diperpanjang tiap hari tanpa background task Dart.
class RefreshAlarmPlan {
  const RefreshAlarmPlan(this.scheduler);

  final AlarmScheduler scheduler;
  static const horizonDays = 30;

  Future<List<AlarmOccurrence>> call({
    required GeoPoint location,
    required CalculationMethod method,
    required AlarmSettings settings,
    DateTime? localNow,
  }) async {
    final calc = PrayerTimeCalculator(method: method);
    final planner = BuildAlarmPlan(NightThirdCalculator(calc, location));
    final plan = planner(
      settings: settings,
      localNow: localNow ?? DateTime.now(),
      horizonDays: horizonDays,
    );
    await scheduler.replaceAll(plan);
    return plan;
  }
}

import '../../../../core/astronomy/night_third_calculator.dart';
import '../entities/alarm_occurrence.dart';
import '../entities/alarm_settings.dart';

/// Membangun daftar alarm bertanggal untuk [horizonDays] malam ke depan.
///
/// Inilah inti "alarm yang ikut bergeser": setiap malam punya instan sendiri,
/// dihitung dari Maghrib dan Subuh malam itu, bukan jam tetap yang berulang.
class BuildAlarmPlan {
  const BuildAlarmPlan(this.nights);

  final NightThirdCalculator nights;

  /// Pra-Subuh dilewati jika jaraknya ≤ 5 menit dari alarm Tahajud.
  static const mergeWindow = Duration(minutes: 5);

  List<AlarmOccurrence> call({
    required AlarmSettings settings,
    required DateTime localNow,
    int horizonDays = 30,
  }) {
    if (settings.uzurMode) return const [];
    final nowUtc = localNow.toUtc();
    final plan = <AlarmOccurrence>[];
    // Mulai dari malam kemarin sore agar alarm dini hari ini ikut terjadwal.
    final first = DateTime(localNow.year, localNow.month, localNow.day)
        .subtract(const Duration(days: 1));

    for (var i = 0; i <= horizonDays; i++) {
      final night = nights.forEvening(first.add(Duration(days: i)));
      final fajrLocal = night.fajr.toLocal();
      final fajrLabel = _hm(fajrLocal);

      DateTime? tahajudAt;
      if (settings.tahajudEnabled) {
        try {
          tahajudAt = settings.tahajudRule.resolve(night);
        } on TahajudRuleError {
          tahajudAt = null; // jam tetap jatuh setelah Subuh: lewati malam ini
        }
        if (tahajudAt != null) {
          plan.add(_occ(
            settings,
            AlarmKind.tahajud,
            fajrLocal,
            tahajudAt,
            'Waktunya Tahajud',
            night.thirdIndexAt(tahajudAt) == 2
                ? 'Sepertiga malam terakhir. Subuh pukul $fajrLabel.'
                : 'Subuh pukul $fajrLabel.',
          ));
        }
      }

      if (settings.preFajrEnabled) {
        final at = night.fajr.subtract(Duration(minutes: settings.preFajrMinutes));
        final tooClose =
            tahajudAt != null && at.difference(tahajudAt).abs() <= mergeWindow;
        if (!tooClose) {
          plan.add(_occ(
            settings,
            AlarmKind.preFajr,
            fajrLocal,
            at,
            'Subuh ${settings.preFajrMinutes} menit lagi',
            'Bersiap wudu. Adzan pukul $fajrLabel.',
          ));
        }
      }

      if (settings.fajrEnabled) {
        plan.add(_occ(
          settings,
          AlarmKind.fajr,
          fajrLocal,
          night.fajr,
          'Adzan Subuh',
          'Ash-shalatu khairum minan naum.',
        ));
      }
    }

    plan.removeWhere((o) => !o.triggerAt.isAfter(nowUtc));
    plan.sort((a, b) => a.triggerAt.compareTo(b.triggerAt));
    return plan;
  }

  AlarmOccurrence _occ(
    AlarmSettings s,
    AlarmKind kind,
    DateTime fajrLocal,
    DateTime at,
    String title,
    String body,
  ) {
    final isTahajud = kind == AlarmKind.tahajud;
    return AlarmOccurrence(
      id: AlarmOccurrence.makeId(fajrLocal, kind),
      kind: kind,
      triggerAt: at.toUtc(),
      title: title,
      body: body,
      sound: isTahajud ? s.tahajudSound : s.fajrSound,
      fadeInSeconds: s.fadeInSeconds,
      // Pra-Subuh hanya pengingat: tanpa misi, satu ketuk untuk menutup.
      mission: switch (kind) {
        AlarmKind.tahajud => s.tahajudMission,
        AlarmKind.fajr => s.fajrMission,
        _ => MissionType.none,
      },
      snoozeLimit: kind == AlarmKind.fajr ? 0 : s.snoozeLimit,
      snoozeMinutes: s.snoozeMinutes,
    );
  }

  static String _hm(DateTime t) =>
      '${t.hour.toString().padLeft(2, '0')}.${t.minute.toString().padLeft(2, '0')}';
}

import '../entities/alarm_occurrence.dart';

/// Kontrak penjadwal alarm. Implementasi Android ada di
/// data/native_alarm_scheduler.dart (MethodChannel → AlarmManager).
abstract interface class AlarmScheduler {
  /// Mengganti seluruh jadwal: membatalkan yang lama, memasang yang baru.
  Future<void> replaceAll(List<AlarmOccurrence> plan);

  /// Menghentikan alarm yang sedang berbunyi (dipanggil setelah misi selesai).
  Future<void> stopRinging(int alarmId);

  /// Menunda alarm yang sedang berbunyi.
  Future<void> snooze(int alarmId, Duration delay);

  /// ID alarm yang membuka aplikasi lewat full-screen intent, jika ada.
  Future<int?> takeLaunchAlarmId();
}

import 'dart:convert';

import 'package:flutter/services.dart';

import '../domain/entities/alarm_occurrence.dart';
import '../domain/repositories/alarm_scheduler.dart';

/// Jembatan ke AlarmBridge.kt. Native menyimpan rencana di device-protected
/// storage, memasang setiap alarm dengan AlarmManager.setAlarmClock(), dan
/// menjadwalkan ulang sendiri setelah reboot tanpa perlu Flutter berjalan.
class NativeAlarmScheduler implements AlarmScheduler {
  NativeAlarmScheduler([MethodChannel? channel])
      : _ch = channel ?? const MethodChannel(channelName);

  static const channelName = 'id.tahajud.companion/alarm';
  final MethodChannel _ch;

  @override
  Future<void> replaceAll(List<AlarmOccurrence> plan) => _ch.invokeMethod(
        'replaceAll',
        {'planJson': jsonEncode(plan.map((o) => o.toJson()).toList())},
      );

  @override
  Future<void> stopRinging(int alarmId) =>
      _ch.invokeMethod('stopRinging', {'id': alarmId});

  @override
  Future<void> snooze(int alarmId, Duration delay) => _ch.invokeMethod(
        'snooze',
        {'id': alarmId, 'delayMillis': delay.inMilliseconds},
      );

  @override
  Future<int?> takeLaunchAlarmId() => _ch.invokeMethod<int>('takeLaunchAlarmId');

  /// Data alarm yang sedang berbunyi (judul, misi, batas snooze).
  Future<Map<String, Object?>?> ringingAlarm(int id) async {
    final json = await _ch.invokeMethod<String>('getAlarm', {'id': id});
    return json == null ? null : (jsonDecode(json) as Map).cast<String, Object?>();
  }
}

import 'package:flutter/services.dart';

/// Status semua izin yang menentukan apakah alarm benar-benar akan berbunyi.
class AlarmReadiness {
  const AlarmReadiness({
    required this.notifications,
    required this.exactAlarms,
    required this.fullScreenIntent,
    required this.ignoringBatteryOptimizations,
    required this.manufacturer,
  });

  final bool notifications;
  final bool exactAlarms;
  final bool fullScreenIntent;
  final bool ignoringBatteryOptimizations;

  /// Build.MANUFACTURER dalam huruf kecil, misal "xiaomi".
  final String manufacturer;

  /// ROM yang dikenal agresif mematikan aplikasi latar belakang.
  bool get needsAutostartGuide => const {
        'xiaomi', 'redmi', 'poco', 'oppo', 'realme', 'vivo', 'huawei',
        'honor', 'oneplus', 'infinix', 'tecno', 'itel', 'samsung',
      }.contains(manufacturer);

  /// Tiga izin ini wajib; tanpa salah satunya alarm bisa gagal berbunyi.
  bool get isReady => notifications && exactAlarms && fullScreenIntent;
}

enum AlarmSettingsPage {
  notifications,
  exactAlarms,
  fullScreenIntent,
  batteryOptimization,
  oemAutostart,
}

class AlarmPermissionService {
  const AlarmPermissionService([this._ch = const MethodChannel(channelName)]);

  static const channelName = 'id.tahajud.companion/alarm';
  final MethodChannel _ch;

  Future<AlarmReadiness> check() async {
    final m = (await _ch.invokeMapMethod<String, Object?>('checkReadiness'))!;
    return AlarmReadiness(
      notifications: m['notifications'] as bool? ?? false,
      exactAlarms: m['exactAlarms'] as bool? ?? false,
      fullScreenIntent: m['fullScreenIntent'] as bool? ?? false,
      ignoringBatteryOptimizations: m['ignoringBatteryOptimizations'] as bool? ?? false,
      manufacturer: (m['manufacturer'] as String? ?? '').toLowerCase(),
    );
  }

  /// Membuka layar pengaturan sistem yang tepat. Kembali `false` jika gagal.
  Future<bool> open(AlarmSettingsPage page) async =>
      await _ch.invokeMethod<bool>('openSettings', {'page': page.name}) ?? false;
}

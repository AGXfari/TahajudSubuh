import 'package:flutter/material.dart';

import '../theme/night_palette.dart';

/// Filter merah di atas seluruh UI aplikasi. Cahaya merah paling sedikit
/// mengganggu adaptasi gelap mata dan ritme tidur.
///
/// Memakai BlendMode.multiply: hitam tetap hitam, warna terang bergeser ke merah.
class RedTintOverlay extends StatelessWidget {
  const RedTintOverlay({
    super.key,
    required this.enabled,
    this.intensity = 0.35,
    required this.child,
  }) : assert(intensity >= 0 && intensity <= 0.4);

  final bool enabled;

  /// 0–0,4 sesuai PRD.
  final double intensity;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    if (!enabled) return child;
    // Campurkan putih → merah sesuai intensitas, lalu multiply.
    final filter = Color.lerp(Colors.white, NightPalette.tint, intensity / 0.4 * 0.85)!;
    return ColorFiltered(
      colorFilter: ColorFilter.mode(filter, BlendMode.multiply),
      child: child,
    );
  }
}

import 'package:geolocator/geolocator.dart';

import '../storage/local_store.dart';

/// Mengambil lokasi sekali, akurasi rendah (cukup untuk jadwal salat:
/// pergeseran 1 km ≈ < 4 detik). Hasil disimpan; GPS tidak dinyalakan terus.
class LocationService {
  const LocationService();

  Future<SavedLocation?> current({String label = 'Lokasi saat ini'}) async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      return null;
    }
    final pos = await Geolocator.getLastKnownPosition() ??
        await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.low,
            timeLimit: Duration(seconds: 15),
          ),
        );
    return SavedLocation(
      latitude: pos.latitude,
      longitude: pos.longitude,
      elevation: pos.altitude.isFinite ? pos.altitude.clamp(0, 5000).toDouble() : 0,
      label: label,
    );
  }
}

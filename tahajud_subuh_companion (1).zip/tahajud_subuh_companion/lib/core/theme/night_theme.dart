import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'night_palette.dart';

/// Satu-satunya tema aplikasi: gelap, hangat, tanpa putih murni.
ThemeData buildNightTheme() {
  const family = 'PlusJakartaSans';
  const tabular = [FontFeature.tabularFigures()];

  final scheme = const ColorScheme.dark(
    surface: NightPalette.malam,
    onSurface: NightPalette.perkamen,
    primary: NightPalette.lentera,
    onPrimary: NightPalette.malam,
    secondary: NightPalette.fajar,
    onSecondary: NightPalette.malam,
    surfaceContainerHighest: NightPalette.arang,
    outline: NightPalette.bara,
    error: Color(0xFFE07A5F),
  );

  const text = TextTheme(
    // Hitung mundur: besar, tipis, angka tabular agar tidak bergoyang.
    displayMedium: TextStyle(
      fontSize: 48, fontWeight: FontWeight.w300, height: 1.05,
      letterSpacing: -1.2, fontFeatures: tabular,
    ),
    headlineSmall: TextStyle(fontSize: 28, fontWeight: FontWeight.w400, fontFeatures: tabular),
    titleMedium: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, height: 1.3),
    bodyLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w400, height: 1.45),
    bodyMedium: TextStyle(fontSize: 15, fontWeight: FontWeight.w400, height: 1.45, fontFeatures: tabular),
    bodySmall: TextStyle(fontSize: 13, fontWeight: FontWeight.w400, height: 1.4, fontFeatures: tabular),
    labelLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
  );

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: NightPalette.malam,
    fontFamily: family,
    textTheme: text.apply(bodyColor: NightPalette.perkamen, displayColor: NightPalette.perkamen),
    splashFactory: NoSplash.splashFactory, // tanpa kilatan ripple terang
    highlightColor: Colors.transparent,
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? NightPalette.malam : NightPalette.bara,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? NightPalette.lentera : NightPalette.arang,
      ),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: NightPalette.malam,
      indicatorColor: NightPalette.arang,
      height: 64,
      labelTextStyle: WidgetStateProperty.resolveWith(
        (s) => TextStyle(
          fontFamily: family,
          fontSize: 12,
          fontWeight: s.contains(WidgetState.selected) ? FontWeight.w600 : FontWeight.w400,
          color: s.contains(WidgetState.selected) ? NightPalette.perkamen : NightPalette.bara,
        ),
      ),
      iconTheme: WidgetStateProperty.resolveWith(
        (s) => IconThemeData(
          color: s.contains(WidgetState.selected) ? NightPalette.lentera : NightPalette.bara,
        ),
      ),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: NightPalette.malam,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: NightPalette.malam,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    ),
  );
}

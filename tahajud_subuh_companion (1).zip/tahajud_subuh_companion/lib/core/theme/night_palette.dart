import 'package:flutter/painting.dart';

/// Token warna UI malam. Nama diambil dari suasana malam, bukan fungsi teknis.
abstract final class NightPalette {
  /// Latar: hitam murni agar piksel AMOLED mati.
  static const malam = Color(0xFF000000);

  /// Permukaan sekunder (sheet, field).
  static const arang = Color(0xFF15110C);

  /// Aksen utama: sepertiga terakhir, tombol utama.
  static const lentera = Color(0xFFE8A33D);

  /// Aksen kedua: Subuh, ikon aktif.
  static const fajar = Color(0xFFC9A86A);

  /// Teks utama — kontras 15,4:1 di atas malam.
  static const perkamen = Color(0xFFEADBC4);

  /// Teks sekunder & busur tidak aktif — kontras 5,1:1.
  static const bara = Color(0xFF8A7A66);

  /// Lapisan filter merah.
  static const tint = Color(0xFFFF3B1F);
}

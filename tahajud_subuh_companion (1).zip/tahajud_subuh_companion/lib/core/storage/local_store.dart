import 'dart:convert';

import 'package:hive_ce_flutter/hive_flutter.dart';

import '../../features/alarm/domain/entities/alarm_settings.dart';
import '../astronomy/prayer_time_calculator.dart';

/// Lokasi tersimpan (dari GPS terakhir atau dipilih manual).
class SavedLocation {
  const SavedLocation({
    required this.latitude,
    required this.longitude,
    required this.label,
    this.elevation = 0,
  });

  final double latitude;
  final double longitude;
  final double elevation;
  final String label;

  GeoPoint get geo => GeoPoint(latitude, longitude, elevation: elevation);

  Map<String, Object> toJson() => {
        'lat': latitude,
        'lng': longitude,
        'elev': elevation,
        'label': label,
      };

  factory SavedLocation.fromJson(Map<String, Object?> j) => SavedLocation(
        latitude: (j['lat'] as num).toDouble(),
        longitude: (j['lng'] as num).toDouble(),
        elevation: (j['elev'] as num?)?.toDouble() ?? 0,
        label: j['label'] as String? ?? 'Lokasi tersimpan',
      );
}

enum FajrStatus { onTime, jamaah, late, missed, uzur }

/// Catatan ibadah satu pagi (kunci = tanggal Subuh, yyyy-mm-dd).
class DayRecord {
  const DayRecord({required this.date, this.tahajud = false, this.fajr});
  final DateTime date;
  final bool tahajud;
  final FajrStatus? fajr;

  /// Uzur tidak memutus streak.
  bool get keepsStreak =>
      fajr == FajrStatus.onTime || fajr == FajrStatus.jamaah || fajr == FajrStatus.uzur;
}

/// Semua data lokal dalam dua box Hive. Nilai disimpan sebagai JSON string
/// agar tidak perlu TypeAdapter dan mudah dimigrasi.
class LocalStore {
  LocalStore._(this._prefs, this._journal);

  final Box<String> _prefs;
  final Box<String> _journal;

  static Future<LocalStore> open() async {
    await Hive.initFlutter();
    final prefs = await Hive.openBox<String>('prefs');
    final journal = await Hive.openBox<String>('journal');
    return LocalStore._(prefs, journal);
  }

  AlarmSettings get alarmSettings {
    final raw = _prefs.get('alarmSettings');
    return raw == null
        ? const AlarmSettings()
        : AlarmSettings.fromJson((jsonDecode(raw) as Map).cast<String, Object?>());
  }

  Future<void> saveAlarmSettings(AlarmSettings s) =>
      _prefs.put('alarmSettings', jsonEncode(s.toJson()));

  /// Default Kemenag; pengguna di luar Indonesia diarahkan ke MWL saat onboarding.
  CalculationMethod get method =>
      CalculationMethod.byId(_prefs.get('method') ?? CalculationMethod.kemenag.id);

  Future<void> saveMethod(CalculationMethod m) => _prefs.put('method', m.id);

  SavedLocation? get location {
    final raw = _prefs.get('location');
    return raw == null
        ? null
        : SavedLocation.fromJson((jsonDecode(raw) as Map).cast<String, Object?>());
  }

  Future<void> saveLocation(SavedLocation l) => _prefs.put('location', jsonEncode(l.toJson()));

  bool get redTint => _prefs.get('redTint') == 'true';
  Future<void> saveRedTint(bool on) => _prefs.put('redTint', '$on');

  // ---- Jurnal --------------------------------------------------------------

  static String _key(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  DayRecord record(DateTime date) {
    final raw = _journal.get(_key(date));
    if (raw == null) return DayRecord(date: date);
    final j = (jsonDecode(raw) as Map).cast<String, Object?>();
    return DayRecord(
      date: date,
      tahajud: j['tahajud'] as bool? ?? false,
      fajr: FajrStatus.values.where((s) => s.name == j['fajr']).firstOrNull,
    );
  }

  Future<void> saveRecord(DayRecord r) => _journal.put(
        _key(r.date),
        jsonEncode({'tahajud': r.tahajud, if (r.fajr != null) 'fajr': r.fajr!.name}),
      );

  /// [n] hari terakhir, terlama dulu, berakhir di [today].
  List<DayRecord> lastDays(DateTime today, int n) => [
        for (var i = n - 1; i >= 0; i--)
          record(DateTime(today.year, today.month, today.day - i)),
      ];

  int fajrStreak(DateTime today) {
    var streak = 0;
    for (var i = 0; i < 3650; i++) {
      final r = record(DateTime(today.year, today.month, today.day - i));
      if (!r.keepsStreak) {
        // Hari ini belum dicatat bukan berarti putus.
        if (i == 0 && r.fajr == null) continue;
        break;
      }
      if (r.fajr != FajrStatus.uzur) streak++;
    }
    return streak;
  }
}

// Kalkulator sepertiga malam terakhir, Dart murni.
//
// Definisi (sesuai PRD): malam = Maghrib hari H sampai Subuh hari H+1.
//   durasi            = subuh(H+1) − maghrib(H)
//   awal sepertiga 2  = maghrib + durasi / 3
//   awal sepertiga 3  = maghrib + 2 × durasi / 3  ( = subuh − durasi / 3 )
//   tengah malam      = maghrib + durasi / 2

import 'prayer_time_calculator.dart';

/// Satu malam lengkap dengan pembagian tiga.
class NightThirds {
  NightThirds({required this.maghrib, required this.fajr})
      : assert(fajr.isAfter(maghrib), 'Subuh harus setelah Maghrib');

  /// Maghrib malam ini (UTC).
  final DateTime maghrib;

  /// Subuh keesokan paginya (UTC).
  final DateTime fajr;

  Duration get duration => fajr.difference(maghrib);

  /// Sepertiga durasi malam, presisi mikrodetik.
  Duration get third => Duration(microseconds: duration.inMicroseconds ~/ 3);

  DateTime get secondThirdStart => maghrib.add(third);
  DateTime get lastThirdStart => fajr.subtract(third);
  DateTime get midnight =>
      maghrib.add(Duration(microseconds: duration.inMicroseconds ~/ 2));

  /// 0 = sepertiga pertama, 1 = kedua, 2 = terakhir, null = di luar malam ini.
  int? thirdIndexAt(DateTime t) {
    if (t.isBefore(maghrib) || !t.isBefore(fajr)) return null;
    if (t.isBefore(secondThirdStart)) return 0;
    if (t.isBefore(lastThirdStart)) return 1;
    return 2;
  }

  /// Posisi [t] di sepanjang malam, 0.0 (Maghrib) sampai 1.0 (Subuh).
  double progressAt(DateTime t) {
    final p = t.difference(maghrib).inMicroseconds / duration.inMicroseconds;
    return p.clamp(0.0, 1.0);
  }
}

class NightThirdCalculator {
  const NightThirdCalculator(this.calculator, this.location);

  final PrayerTimeCalculator calculator;
  final GeoPoint location;

  /// Malam yang dimulai pada Maghrib tanggal sipil [eveningDate].
  NightThirds forEvening(DateTime eveningDate) {
    final d = DateTime.utc(eveningDate.year, eveningDate.month, eveningDate.day);
    final next = d.add(const Duration(days: 1));
    final today = calculator.compute(location, d.year, d.month, d.day);
    final tomorrow = calculator.compute(location, next.year, next.month, next.day);
    return NightThirds(maghrib: today.maghrib, fajr: tomorrow.fajr);
  }

  /// Malam yang sedang berlangsung, atau malam berikutnya jika sekarang siang.
  ///
  /// [localNow] adalah waktu sipil lokal (DateTime.now()), dipakai untuk
  /// menentukan tanggal; perbandingan waktu tetap memakai instan UTC.
  NightThirds currentOrNext(DateTime localNow) {
    final todayDate = DateTime.utc(localNow.year, localNow.month, localNow.day);
    final yesterday = todayDate.subtract(const Duration(days: 1));
    final lastNight = forEvening(yesterday);
    // Sebelum Subuh hari ini → masih malam yang dimulai kemarin sore.
    if (localNow.toUtc().isBefore(lastNight.fajr)) return lastNight;
    return forEvening(todayDate);
  }
}

// ---------------------------------------------------------------------------
// Aturan alarm Tahajud
// ---------------------------------------------------------------------------

sealed class TahajudRule {
  const TahajudRule();

  /// Instan alarm (UTC) untuk [night], dibulatkan ke menit.
  DateTime resolve(NightThirds night);

  Map<String, Object> toJson();

  static TahajudRule fromJson(Map<String, Object?> j) => switch (j['type']) {
        'lastThird' => LastThirdRule(offsetMinutes: j['offset'] as int? ?? 0),
        'beforeFajr' => BeforeFajrRule(minutesBefore: j['minutes'] as int? ?? 45),
        'fixed' => FixedTimeRule(hour: j['hour'] as int, minute: j['minute'] as int),
        _ => const LastThirdRule(),
      };
}

/// Awal sepertiga malam terakhir, digeser [offsetMinutes] (boleh negatif).
class LastThirdRule extends TahajudRule {
  const LastThirdRule({this.offsetMinutes = 0});
  final int offsetMinutes;

  @override
  DateTime resolve(NightThirds night) =>
      // Dibulatkan ke atas agar alarm tidak berbunyi sebelum sepertiga terakhir.
      _ceilMinute(night.lastThirdStart.add(Duration(minutes: offsetMinutes)));

  @override
  Map<String, Object> toJson() => {'type': 'lastThird', 'offset': offsetMinutes};
}

/// Relatif terhadap Subuh, misalnya 45 menit sebelum adzan.
class BeforeFajrRule extends TahajudRule {
  const BeforeFajrRule({required this.minutesBefore})
      : assert(minutesBefore > 0 && minutesBefore <= 240);
  final int minutesBefore;

  @override
  DateTime resolve(NightThirds night) =>
      night.fajr.subtract(Duration(minutes: minutesBefore));

  @override
  Map<String, Object> toJson() => {'type': 'beforeFajr', 'minutes': minutesBefore};
}

/// Jam tetap (waktu lokal perangkat). Ditolak jika jatuh di luar malam.
class FixedTimeRule extends TahajudRule {
  const FixedTimeRule({required this.hour, required this.minute});
  final int hour;
  final int minute;

  @override
  DateTime resolve(NightThirds night) {
    // Cari kemunculan jam ini setelah Maghrib malam tersebut (zona perangkat).
    final m = night.maghrib.toLocal();
    var candidate = DateTime(m.year, m.month, m.day, hour, minute);
    if (!candidate.isAfter(m)) candidate = candidate.add(const Duration(days: 1));
    final utc = candidate.toUtc();
    if (!utc.isBefore(night.fajr)) {
      throw TahajudRuleError('Jam $hour:${minute.toString().padLeft(2, '0')} '
          'jatuh setelah Subuh. Pilih jam sebelum Subuh.');
    }
    return utc;
  }

  @override
  Map<String, Object> toJson() => {'type': 'fixed', 'hour': hour, 'minute': minute};
}

class TahajudRuleError implements Exception {
  TahajudRuleError(this.message);
  final String message;
  @override
  String toString() => message;
}

DateTime _ceilMinute(DateTime t) {
  final ms = t.millisecondsSinceEpoch;
  final r = ms % 60000;
  return DateTime.fromMillisecondsSinceEpoch(r == 0 ? ms : ms - r + 60000,
      isUtc: true);
}

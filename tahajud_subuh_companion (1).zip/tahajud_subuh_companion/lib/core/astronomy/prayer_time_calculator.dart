// Mesin waktu salat offline, Dart murni (tanpa dependensi Flutter).
//
// Model posisi matahari: algoritma ringkas U.S. Naval Observatory yang juga
// dipakai PrayTimes.org. Akurasi deklinasi/equation of time < 1 menit untuk
// tahun 1950–2050, cukup untuk jadwal yang dibulatkan ke menit.
//
// Semua hasil dikembalikan sebagai instan UTC (DateTime.isUtc == true).
// UI cukup memanggil .toLocal(); alarm memakai millisecondsSinceEpoch.

import 'dart:math' as math;

/// Parameter satu metode perhitungan.
class CalculationMethod {
  const CalculationMethod({
    required this.id,
    required this.name,
    required this.fajrAngle,
    required this.ishaAngle,
    this.ihtiyatMinutes = 0,
    this.roundUpToMinute = false,
    this.dhuhrExtraMinutes = 0,
    this.fixedRiseSetAngle,
    this.highLatitudeRule = HighLatitudeRule.angleBased,
  });

  final String id;
  final String name;

  /// Depresi matahari (derajat di bawah ufuk) untuk Subuh dan Isya.
  final double fajrAngle;
  final double ishaAngle;

  /// Ihtiyat (kehati-hatian): ditambahkan ke semua waktu, dikurangkan dari terbit.
  final int ihtiyatMinutes;

  /// Kemenag membulatkan detik ke atas ke menit berikutnya.
  final bool roundUpToMinute;

  /// Tambahan khusus Dzuhur (di atas ihtiyat), agar awal waktu jatuh
  /// setelah piringan matahari melewati meridian.
  final int dhuhrExtraMinutes;

  /// Sudut matahari saat terbit/terbenam (derajat di bawah ufuk). null =
  /// dihitung dari refraksi + semidiameter (0,833°) + kerendahan ufuk dari elevasi.
  final double? fixedRiseSetAngle;

  final HighLatitudeRule highLatitudeRule;

  /// Kemenag RI: Subuh −20°, Isya −18°, ihtiyat 2 menit, pembulatan ke atas.
  /// Terbit/terbenam −1° dan Dzuhur +1 menit dikalibrasi terhadap jadwal resmi
  /// Bimas Islam (lihat tool/validate_surakarta.dart).
  static const kemenag = CalculationMethod(
    id: 'kemenag',
    name: 'Kemenag RI',
    fajrAngle: 20,
    ishaAngle: 18,
    ihtiyatMinutes: 2,
    roundUpToMinute: true,
    dhuhrExtraMinutes: 1,
    fixedRiseSetAngle: 1.0,
  );

  /// Muslim World League: Subuh −18°, Isya −17°.
  static const muslimWorldLeague = CalculationMethod(
    id: 'mwl',
    name: 'Muslim World League',
    fajrAngle: 18,
    ishaAngle: 17,
  );

  static const all = [kemenag, muslimWorldLeague];

  static CalculationMethod byId(String id) =>
      all.firstWhere((m) => m.id == id, orElse: () => kemenag);
}

/// Aturan untuk lintang tinggi saat matahari tidak turun sampai sudut Subuh/Isya.
enum HighLatitudeRule { none, angleBased, middleOfNight, oneSeventh }

enum Prayer { fajr, sunrise, dhuhr, asr, maghrib, isha }

/// Satu hari jadwal salat. Semua DateTime dalam UTC.
class PrayerTimes {
  const PrayerTimes({
    required this.date,
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });

  /// Tanggal sipil lokal (hanya y/m/d yang bermakna).
  final DateTime date;
  final DateTime fajr;
  final DateTime sunrise;
  final DateTime dhuhr;
  final DateTime asr;
  final DateTime maghrib;
  final DateTime isha;

  /// Imsak = Subuh − 10 menit (konvensi Kemenag).
  DateTime get imsak => fajr.subtract(const Duration(minutes: 10));

  DateTime operator [](Prayer p) => switch (p) {
        Prayer.fajr => fajr,
        Prayer.sunrise => sunrise,
        Prayer.dhuhr => dhuhr,
        Prayer.asr => asr,
        Prayer.maghrib => maghrib,
        Prayer.isha => isha,
      };
}

/// Koordinat pengamat.
class GeoPoint {
  const GeoPoint(this.latitude, this.longitude, {this.elevation = 0});
  final double latitude;
  final double longitude;

  /// Ketinggian tempat dalam meter, memengaruhi terbit dan Maghrib.
  final double elevation;
}

class PrayerTimeCalculator {
  const PrayerTimeCalculator({
    this.method = CalculationMethod.kemenag,
    this.asrShadowFactor = 1, // 1 = Syafi'i/Maliki/Hanbali, 2 = Hanafi
    this.adjustmentsMinutes = const {},
  });

  final CalculationMethod method;
  final int asrShadowFactor;

  /// Koreksi manual pengguna per waktu, dalam menit (boleh negatif).
  final Map<Prayer, int> adjustmentsMinutes;

  /// Menghitung jadwal untuk tanggal sipil lokal [year]-[month]-[day].
  PrayerTimes compute(GeoPoint loc, int year, int month, int day) {
    final lat = loc.latitude;
    final lng = loc.longitude;
    // Hari Julian pada tengah malam lokal (dikoreksi bujur).
    final jDate = _julian(year, month, day) - lng / (15 * 24);

    double midDay(double t) => _fixHour(12 - _sun(jDate + t / 24).eqt);

    double sunAngleTime(double angle, double t, {bool beforeNoon = false}) {
      final decl = _sun(jDate + t / 24).decl;
      final noon = midDay(t);
      final cosT = (-_sin(angle) - _sin(decl) * _sin(lat)) /
          (_cos(decl) * _cos(lat));
      if (cosT < -1 || cosT > 1) return double.nan; // tidak tercapai
      final h = _acos(cosT) / 15;
      return noon + (beforeNoon ? -h : h);
    }

    double asrTime(double t) {
      final decl = _sun(jDate + t / 24).decl;
      final angle = -_acot(asrShadowFactor + _tan((lat - decl).abs()));
      return sunAngleTime(angle, t);
    }

    final riseSetAngle = method.fixedRiseSetAngle ??
        0.833 + 0.0347 * math.sqrt(math.max(0, loc.elevation));

    // Tebakan awal (jam matahari lokal), lalu dua iterasi penyempurnaan.
    var fajr = 5.0, sunrise = 6.0, dhuhr = 12.0, asr = 13.0;
    var sunset = 18.0, isha = 18.0;
    for (var i = 0; i < 2; i++) {
      fajr = sunAngleTime(method.fajrAngle, _orDefault(fajr, 5), beforeNoon: true);
      sunrise = sunAngleTime(riseSetAngle, _orDefault(sunrise, 6), beforeNoon: true);
      dhuhr = midDay(_orDefault(dhuhr, 12));
      asr = asrTime(_orDefault(asr, 13));
      sunset = sunAngleTime(riseSetAngle, _orDefault(sunset, 18));
      isha = sunAngleTime(method.ishaAngle, _orDefault(isha, 18));
    }

    // Lintang tinggi: batasi Subuh/Isya terhadap porsi malam.
    if (method.highLatitudeRule != HighLatitudeRule.none) {
      final night = _fixHour(sunrise - sunset); // terbenam → terbit
      double portion(double angle) => switch (method.highLatitudeRule) {
            HighLatitudeRule.angleBased => angle / 60,
            HighLatitudeRule.oneSeventh => 1 / 7,
            HighLatitudeRule.middleOfNight => 1 / 2,
            HighLatitudeRule.none => 1,
          };
      final fajrLimit = portion(method.fajrAngle) * night;
      if (fajr.isNaN || _fixHour(sunrise - fajr) > fajrLimit) {
        fajr = sunrise - fajrLimit;
      }
      final ishaLimit = portion(method.ishaAngle) * night;
      if (isha.isNaN || _fixHour(isha - sunset) > ishaLimit) {
        isha = sunset + ishaLimit;
      }
    }

    // Jam matahari lokal → jam UTC.
    final tzShift = lng / 15;
    final base = DateTime.utc(year, month, day);
    final ih = method.ihtiyatMinutes;

    DateTime finish(Prayer p, double localSolarHours, int ihtiyat) {
      final utcHours = localSolarHours - tzShift;
      final seconds = (utcHours * 3600).round();
      var t = base.add(Duration(seconds: seconds));
      t = t.add(Duration(minutes: ihtiyat + (adjustmentsMinutes[p] ?? 0)));
      return method.roundUpToMinute ? _ceilMinute(t) : _roundMinute(t);
    }

    return PrayerTimes(
      date: DateTime.utc(year, month, day),
      fajr: finish(Prayer.fajr, fajr, ih),
      sunrise: method.roundUpToMinute
          // Terbit dikurangi ihtiyat dan dibulatkan ke bawah (lebih hati-hati).
          ? _floorMinute(base
              .add(Duration(seconds: ((sunrise - tzShift) * 3600).round()))
              .subtract(Duration(minutes: ih - (adjustmentsMinutes[Prayer.sunrise] ?? 0))))
          : finish(Prayer.sunrise, sunrise, 0),
      dhuhr: finish(Prayer.dhuhr, dhuhr, ih + method.dhuhrExtraMinutes),
      asr: finish(Prayer.asr, asr, ih),
      maghrib: finish(Prayer.maghrib, sunset, ih),
      isha: finish(Prayer.isha, isha, ih),
    );
  }

  // ---------------------------------------------------------------------
  // Astronomi
  // ---------------------------------------------------------------------

  static ({double decl, double eqt}) _sun(double jd) {
    final d = jd - 2451545.0;
    final g = _fixAngle(357.529 + 0.98560028 * d);
    final q = _fixAngle(280.459 + 0.98564736 * d);
    final l = _fixAngle(q + 1.915 * _sin(g) + 0.020 * _sin(2 * g));
    final e = 23.439 - 0.00000036 * d;
    final ra = _atan2(_cos(e) * _sin(l), _cos(l)) / 15;
    final eqt = q / 15 - _fixHour(ra);
    final decl = _asin(_sin(e) * _sin(l));
    return (decl: decl, eqt: eqt);
  }

  static double _julian(int year, int month, int day) {
    var y = year, m = month;
    if (m <= 2) {
      y -= 1;
      m += 12;
    }
    final a = (y / 100).floor();
    final b = 2 - a + (a / 4).floor();
    return (365.25 * (y + 4716)).floor() +
        (30.6001 * (m + 1)).floor() +
        day +
        b -
        1524.5;
  }

  static double _orDefault(double v, double d) => v.isNaN ? d : v;

  static DateTime _ceilMinute(DateTime t) {
    final ms = t.millisecondsSinceEpoch;
    const m = 60000;
    final r = ms % m;
    return DateTime.fromMillisecondsSinceEpoch(r == 0 ? ms : ms - r + m, isUtc: true);
  }

  static DateTime _floorMinute(DateTime t) {
    final ms = t.millisecondsSinceEpoch;
    return DateTime.fromMillisecondsSinceEpoch(ms - ms % 60000, isUtc: true);
  }

  static DateTime _roundMinute(DateTime t) =>
      _floorMinute(t.add(const Duration(seconds: 30)));
}

// Trigonometri dalam derajat.
double _dtr(double d) => d * math.pi / 180;
double _rtd(double r) => r * 180 / math.pi;
double _sin(double d) => math.sin(_dtr(d));
double _cos(double d) => math.cos(_dtr(d));
double _tan(double d) => math.tan(_dtr(d));
double _asin(double x) => _rtd(math.asin(x));
double _acos(double x) => _rtd(math.acos(x));
double _atan2(double y, double x) => _rtd(math.atan2(y, x));
double _acot(double x) => _rtd(math.atan(1 / x));
double _fix(double a, double b) {
  final r = a - b * (a / b).floor();
  return r < 0 ? r + b : r;
}

double _fixAngle(double a) => _fix(a, 360);
double _fixHour(double a) => _fix(a, 24);

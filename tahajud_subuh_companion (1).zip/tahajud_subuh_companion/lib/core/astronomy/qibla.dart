// Arah kiblat (azimut great-circle dari utara sejati, searah jarum jam).
import 'dart:math' as math;

const kaabaLatitude = 21.422487;
const kaabaLongitude = 39.826206;

/// Azimut kiblat dalam derajat (0–360) dari utara sejati.
double qiblaBearing(double latitude, double longitude) {
  final phi = latitude * math.pi / 180;
  final phiK = kaabaLatitude * math.pi / 180;
  final dLambda = (kaabaLongitude - longitude) * math.pi / 180;
  final y = math.sin(dLambda);
  final x = math.cos(phi) * math.tan(phiK) - math.sin(phi) * math.cos(dLambda);
  final deg = math.atan2(y, x) * 180 / math.pi;
  return (deg + 360) % 360;
}

/// Sudut yang ditampilkan jarum kompas: kiblat relatif terhadap arah HP.
/// [headingMagnetic] dari magnetometer, [declination] dari GeomagneticField
/// Android (timur positif).
double qiblaNeedleAngle({
  required double qiblaTrue,
  required double headingMagnetic,
  required double declination,
}) {
  final headingTrue = headingMagnetic + declination;
  return (qiblaTrue - headingTrue + 360) % 360;
}

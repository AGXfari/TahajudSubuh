import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/night_palette.dart';
import '../../dashboard/presentation/dashboard_view_model.dart';
import '../data/native_alarm_scheduler.dart';

/// Layar alarm. Tidak ada tombol matikan: alarm berhenti setelah misi selesai.
/// Paket ini memuat misi matematika; misi kuis, goyang, dan QR mengikuti
/// antarmuka [MissionView] yang sama (lihat PRD, fitur 3).
class RingPage extends ConsumerStatefulWidget {
  const RingPage({super.key, required this.alarmId});
  final int alarmId;

  @override
  ConsumerState<RingPage> createState() => _RingPageState();
}

class _RingPageState extends ConsumerState<RingPage> {
  Map<String, Object?>? _alarm;

  @override
  void initState() {
    super.initState();
    NativeAlarmScheduler().ringingAlarm(widget.alarmId).then((a) {
      if (mounted) setState(() => _alarm = a);
    });
  }

  Future<void> _finish() async {
    final scheduler = ref.read(alarmSchedulerProvider);
    await scheduler.stopRinging(widget.alarmId);
    // Pengguna membuka aplikasi tiap pagi lewat misi → jadwal diperpanjang di sini.
    await ref.read(dashboardProvider.notifier).onResume();
    if (!mounted) return;
    final nav = Navigator.of(context);
    nav.canPop() ? nav.pop() : nav.pushReplacementNamed('/');
  }

  Future<void> _snooze(int minutes) async {
    await ref.read(alarmSchedulerProvider).snooze(widget.alarmId, Duration(minutes: minutes));
    await SystemNavigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final a = _alarm;
    final mission = a?['mission'] as String? ?? 'math';
    final snoozeLeft = (a?['snoozeLimit'] as int? ?? 0) - (a?['snoozeCount'] as int? ?? 0);
    final snoozeMinutes = a?['snoozeMinutes'] as int? ?? 5;

    return PopScope(
      canPop: false, // tombol Back tidak mematikan alarm
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(a?['title'] as String? ?? 'Alarm', style: t.headlineSmall),
                const SizedBox(height: 6),
                Text(a?['body'] as String? ?? '',
                    style: t.bodyLarge!.copyWith(color: NightPalette.bara)),
                const SizedBox(height: 40),
                Expanded(
                  child: mission == 'none'
                      ? Align(
                          alignment: Alignment.topLeft,
                          child: FilledButton(
                            onPressed: _finish,
                            style: FilledButton.styleFrom(minimumSize: const Size(200, 64)),
                            child: const Text('Saya sudah bangun'),
                          ),
                        )
                      : MathMission(onComplete: _finish),
                ),
                if (snoozeLeft > 0)
                  TextButton(
                    onPressed: () => _snooze(snoozeMinutes),
                    child: Text('Tunda $snoozeMinutes menit (sisa $snoozeLeft kali)'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Kontrak semua misi.
abstract class MissionView extends StatefulWidget {
  const MissionView({super.key, required this.onComplete});
  final VoidCallback onComplete;
}

/// Tiga soal; jawaban salah mengganti soal (bukan mengulang yang sama).
class MathMission extends MissionView {
  const MathMission({super.key, required super.onComplete, this.medium = false});
  final bool medium;

  @override
  State<MathMission> createState() => _MathMissionState();
}

class _MathMissionState extends State<MathMission> {
  static const total = 3;
  final _rng = Random();
  final _input = TextEditingController();
  int _solved = 0;
  late (String, int) _q = _next();
  bool _wrong = false;

  (String, int) _next() {
    if (widget.medium) {
      final a = 12 + _rng.nextInt(88), b = 3 + _rng.nextInt(7), c = 10 + _rng.nextInt(90);
      return ('$a × $b + $c', a * b + c);
    }
    final a = 10 + _rng.nextInt(90), b = 10 + _rng.nextInt(90);
    return ('$a + $b', a + b);
  }

  void _submit() {
    if (int.tryParse(_input.text.trim()) == _q.$2) {
      _solved++;
      if (_solved == total) return widget.onComplete();
      setState(() => (_q, _wrong) = (_next(), false));
    } else {
      HapticFeedback.heavyImpact();
      setState(() => (_q, _wrong) = (_next(), true));
    }
    _input.clear();
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Soal ${_solved + 1} dari $total',
            style: t.bodySmall!.copyWith(color: NightPalette.bara)),
        const SizedBox(height: 8),
        Text(_q.$1, style: t.displayMedium),
        const SizedBox(height: 20),
        TextField(
          controller: _input,
          autofocus: true,
          keyboardType: TextInputType.number,
          keyboardAppearance: Brightness.dark,
          style: t.headlineSmall,
          onSubmitted: (_) => _submit(),
          decoration: InputDecoration(
            filled: true,
            fillColor: NightPalette.arang,
            hintText: 'Jawaban',
            errorText: _wrong ? 'Belum tepat. Ini soal baru.' : null,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: _submit,
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(64)),
          child: const Text('Periksa jawaban'),
        ),
      ],
    );
  }
}
